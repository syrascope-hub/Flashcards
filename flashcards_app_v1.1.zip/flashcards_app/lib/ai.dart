import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'secrets.dart';

final ValueNotifier<bool> darkN = ValueNotifier(false);
const _inv = ColorFilter.matrix(<double>[-1.0, 0.0, 0.0, 0.0, 255.0, 0.0, -1.0, 0.0, 0.0, 255.0, 0.0, 0.0, -1.0, 0.0, 255.0, 0.0, 0.0, 0.0, 1.0, 0.0]);
const _hue = ColorFilter.matrix(<double>[-0.574, 1.430, 0.144, 0.0, 0.0, 0.426, 0.430, 0.144, 0.0, 0.0, 0.426, 1.430, -0.856, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0]);
const _id = ColorFilter.mode(Color(0x00000000), BlendMode.dst);

/// وضع داكن: عكس الألوان مع إبقاء درجات اللون (ويُطبَّق مرتين على الصور لإرجاعها كما هي)
Widget darkWrap(bool on, Widget c) => ColorFiltered(
    colorFilter: on ? _hue : _id,
    child: ColorFiltered(colorFilter: on ? _inv : _id, child: c));

String dayKey([int back = 0]) {
  final t = DateTime.now().subtract(Duration(days: back));
  return '${t.year}-${t.month}-${t.day}';
}

/// اللغات المدعومة للبطاقات (رمز النطق -> اسم اللغة)
const kLangs = {
  'en-US': 'English',
  'fr-FR': 'French',
  'es-ES': 'Spanish',
  'de-DE': 'German',
  'it-IT': 'Italian',
  'tr-TR': 'Turkish',
  'ru-RU': 'Russian',
  'ja-JP': 'Japanese',
  'ko-KR': 'Korean',
};
const kLangsAr = {
  'en-US': 'الإنجليزية',
  'fr-FR': 'الفرنسية',
  'es-ES': 'الإسبانية',
  'de-DE': 'الألمانية',
  'it-IT': 'الإيطالية',
  'tr-TR': 'التركية',
  'ru-RU': 'الروسية',
  'ja-JP': 'اليابانية',
  'ko-KR': 'الكورية',
};

Future<String> studyLang() async => (await SharedPreferences.getInstance()).getString('lang') ?? 'en-US';

Future<String> aiAsk(String prompt, {int maxTokens = 120, int timeoutSec = 30}) async {
  final p = await SharedPreferences.getInstance();
  final tok = await Secrets.hfToken();
  if (tok.isEmpty) throw 'أضف مفتاح Hugging Face من الإعدادات';
  final model = p.getString('model') ?? 'Qwen/Qwen2.5-7B-Instruct';
  final r = await http
      .post(Uri.parse('https://router.huggingface.co/v1/chat/completions'),
          headers: {'Authorization': 'Bearer $tok', 'Content-Type': 'application/json'},
          body: jsonEncode({
            'model': model,
            'max_tokens': maxTokens,
            'messages': [
              {'role': 'user', 'content': prompt}
            ]
          }))
      .timeout(Duration(seconds: timeoutSec));
  if (r.statusCode != 200) throw 'فشل الاتصال بالذكاء الاصطناعي (${r.statusCode})';
  final j = jsonDecode(utf8.decode(r.bodyBytes));
  return (j['choices'][0]['message']['content'] as String).trim().replaceAll('"', '');
}

Future<String> aiTranslate(String w) async {
  final l = kLangs[await studyLang()] ?? 'English';
  return aiAsk('Translate the $l word or phrase "$w" to Arabic. Reply with the Arabic translation only, no explanation.');
}

Future<String> aiExample(String w) async {
  final l = kLangs[await studyLang()] ?? 'English';
  return aiAsk('Write one short, simple $l sentence using "$w". Reply with the sentence only.');
}

/// يولّد قائمة بطاقات (كلمة، ترجمة) عن موضوع معيّن
Future<String> aiCards(String topic, int n) async {
  final l = kLangs[await studyLang()] ?? 'English';
  final out = await aiAsk(
      'List $n useful $l words or short phrases about the topic "$topic". '
      'Output exactly one item per line in the format: word, Arabic translation. '
      'No numbering, no headings, no extra text.',
      maxTokens: 60 * n + 100,
      timeoutSec: 60);
  final lines = <String>[];
  for (final raw in out.split('\n')) {
    final l2 = raw.trim().replaceFirst(RegExp(r'^[\d\-\*\.\)\s•]+'), '').trim();
    if (l2.contains(RegExp(r'[,،]'))) lines.add(l2);
  }
  if (lines.isEmpty) throw 'لم يرجع النموذج قائمة صالحة، حاول مرة أخرى';
  return lines.join('\n');
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SetState();
}

class _SetState extends State<SettingsPage> {
  final tok = TextEditingController(), model = TextEditingController();
  double rate = .5;
  int goal = 20;
  bool dk = darkN.value;
  String lang = 'en-US';

  @override
  void initState() {
    super.initState();
    Secrets.hfToken().then((t) {
      if (mounted) setState(() => tok.text = t);
    });
    SharedPreferences.getInstance().then((p) => setState(() {
          lang = p.getString('lang') ?? 'en-US';
          model.text = p.getString('model') ?? 'Qwen/Qwen2.5-7B-Instruct';
          rate = p.getDouble('rate') ?? .5;
          goal = p.getInt('goal') ?? 20;
        }));
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await Secrets.set('hf', tok.text.trim());
    await p.setString('lang', lang);
    await p.setString('model', model.text.trim());
    await p.setDouble('rate', rate);
    await p.setInt('goal', goal);
    await p.setBool('dark', dk);
    if (mounted) Navigator.pop(context);
  }

  Widget h(String s) => Padding(
      padding: const EdgeInsets.only(top: 18, bottom: 6),
      child: Text(s, style: const TextStyle(fontWeight: FontWeight.w800)));

  InputDecoration d() => InputDecoration(
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)));

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('الإعدادات'), backgroundColor: const Color(0xFFF5F6FF)),
        body: SafeArea(
          child: ListView(padding: const EdgeInsets.all(18), children: [
            h('مفتاح Hugging Face (يُحفظ مشفّرًا على جهازك)'),
            TextField(controller: tok, obscureText: true, textDirection: TextDirection.ltr, decoration: d()),
            h('لغة الكلمات التي تتعلمها'),
            Container(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                child: DropdownButton<String>(
                    value: lang,
                    isExpanded: true,
                    underline: const SizedBox(),
                    items: [for (final e in kLangsAr.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
                    onChanged: (v) => setState(() => lang = v ?? 'en-US'))),
            h('نموذج الذكاء الاصطناعي'),
            TextField(controller: model, textDirection: TextDirection.ltr, decoration: d()),
            h('سرعة النطق'),
            Slider(value: rate, min: .2, max: 1, onChanged: (v) => setState(() => rate = v)),
            SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('الوضع الداكن', style: TextStyle(fontWeight: FontWeight.w800)),
                value: dk,
                onChanged: (v) {
                  setState(() => dk = v);
                  darkN.value = v;
                }),
            h('الهدف اليومي: $goal بطاقة'),
            Slider(value: goal.toDouble(), min: 5, max: 100, divisions: 19, onChanged: (v) => setState(() => goal = v.round())),
            const SizedBox(height: 20),
            FilledButton(
                onPressed: save,
                style: FilledButton.styleFrom(backgroundColor: const Color(0xFF0B0B0B), padding: const EdgeInsets.all(16)),
                child: const Text('حفظ', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
          ]),
        ),
      );
}
