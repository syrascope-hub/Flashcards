import 'dart:convert';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';
import 'extras.dart';
import 'ai.dart';
import 'illustrations.dart';
import 'more.dart';
import 'store.dart';
import 'notif.dart';
import 'gam.dart';
import 'games.dart';
import 'ocr.dart';
import 'backup.dart';
import 'sync.dart';
import 'dict.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const App());
}

const mint = Color(0xFF72E3A5);
const lilac = Color(0xFFBFA0EA);
const peri = Color(0xFFB4BEFF);
const bgC = Color(0xFFF5F6FF);
const ink = Color(0xFF0B0B0B);
const sub = Color(0xFF5D5F73);
const pinkC = Color(0xFFFFD3E0);

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'بطاقات الحفظ',
        debugShowCheckedModeBanner: false,
        locale: const Locale('ar'),
        builder: (c, child) =>
            Directionality(
                textDirection: TextDirection.rtl,
                child: ValueListenableBuilder<bool>(
                    valueListenable: darkN,
                    builder: (_, d, __) => darkWrap(d, child!))),
        theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: bgC,
          colorScheme: ColorScheme.fromSeed(seedColor: lilac),
          fontFamily: 'Roboto',
        ),
        home: const Gate(),
      );
}

class Gate extends StatefulWidget {
  const Gate({super.key});
  @override
  State<Gate> createState() => _GateState();
}

class _GateState extends State<Gate> {
  bool? seen;
  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      if (mounted) setState(() => seen = p.getBool('onb') ?? false);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (seen == null) return const Scaffold(body: SizedBox());
    if (seen!) return const Home();
    return OnboardingPage(onDone: () async {
      final p = await SharedPreferences.getInstance();
      await p.setBool('onb', true);
      if (mounted) setState(() => seen = true);
    });
  }
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  List<Flash> cards = [];
  int tab = 0;
  int idx = 0;
  bool flip = false;
  bool bulk = false;
  bool all = false;
  String deck = 'الكل';
  String q = '';
  int streak = 0, cnt = 0, goal = 20;
  bool busy = false;
  bool remDue = false;
  String pickedImg = '';
  bool fav = false;
  String msg = '';
  bool err = false;
  final wC = TextEditingController();
  final tC = TextEditingController();
  final eC = TextEditingController();
  final bC = TextEditingController();
  final xC = TextEditingController();
  final tts = FlutterTts();
  bool loaded = false, hard = false, hardF = false, synced = false;
  int xp = 0, freeze = 0;
  String lang = 'en-US';

  @override
  void initState() {
    super.initState();
    load();
  }

  void toast(String s) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(s), duration: const Duration(seconds: 4)));
  }

  Future<void> syncNotif() async {
    try {
      await Notif.syncFromPrefs();
    } catch (_) {}
  }

  Future<void> autoSync() async {
    try {
      final res = await runSync(() => cards);
      if (!mounted) return;
      setState(() => cards = res.cards);
      save();
    } catch (_) {}
  }

  void startHard() => setState(() {
        tab = 2;
        idx = 0;
        flip = false;
        all = true;
        hard = true;
        msg = '';
      });

  void addScanned(List<Flash> l) {
    setState(() => cards.addAll(l));
    save();
  }

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    goal = p.getInt('goal') ?? 20;
    darkN.value = p.getBool('dark') ?? false;
    lang = p.getString('lang') ?? 'en-US';
    xp = p.getInt('xp') ?? 0;
    freeze = p.getInt('freeze') ?? 0;
    streak = p.getInt('streak') ?? 0;
    final dd = p.getString('day');
    final gap = gapDays(dd);
    if (dd == null || gap > 2 || (gap == 2 && freeze == 0)) streak = 0;
    cnt = dd == dayKey() ? (p.getInt('cnt') ?? 0) : 0;
    tts.setLanguage(lang);
    tts.setSpeechRate(p.getDouble('rate') ?? .5);
    final nowT = TimeOfDay.now();
    remDue = (p.getBool('rem_on') ?? false) &&
        cnt < goal &&
        (nowT.hour * 60 + nowT.minute) >= ((p.getInt('rem_h') ?? 20) * 60 + (p.getInt('rem_m') ?? 0));
    try {
      cards = await Store.load();
    } catch (_) {}
    loaded = true;
    if (mounted) setState(() {});
    syncNotif();
    if (!synced) {
      synced = true;
      if (p.getBool('sync_auto') ?? false) autoSync();
    }
  }

  Future<void> save() async {
    if (!loaded) return;
    try {
      await Store.save(cards);
    } catch (_) {}
  }

  String get curDeck => deck == 'الكل' ? 'عام' : deck;
  List<Flash> get view => deck == 'الكل' ? cards : cards.where((c) => c.d == deck).toList();
  List<String> get decks => {'الكل', ...cards.map((c) => c.d), deck}.toList();

  Future<void> newDeck() async {
    final c = TextEditingController();
    final n = await showDialog<String>(
        context: context,
        builder: (_) => AlertDialog(
              title: const Text('مجموعة جديدة'),
              content: TextField(controller: c, autofocus: true, decoration: const InputDecoration(hintText: 'اسم المجموعة')),
              actions: [TextButton(onPressed: () => Navigator.pop(context, c.text.trim()), child: const Text('إنشاء'))],
            ));
    if (n != null && n.isNotEmpty) setState(() => deck = n);
  }

  Widget deckBar() => SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(children: [
          for (final d in decks)
            Padding(
                padding: const EdgeInsets.only(left: 8, bottom: 14),
                child: ChoiceChip(label: Text(d), selected: deck == d, selectedColor: peri, onSelected: (_) => setState(() => deck = d))),
          Padding(padding: const EdgeInsets.only(bottom: 14), child: ActionChip(label: const Text('+ مجموعة'), onPressed: newDeck)),
        ]),
      );

  Future<void> logReview() async {
    final p = await SharedPreferences.getInstance();
    var usedFreeze = false;
    if (p.getString('day') != dayKey()) {
      final last = p.getString('day');
      final gap = gapDays(last);
      final fr = p.getInt('freeze') ?? 0;
      final old = p.getInt('streak') ?? 0;
      if (last != null && gap == 1) {
        streak = old + 1;
      } else if (last != null && gap == 2 && fr > 0) {
        streak = old + 1;
        usedFreeze = true;
        await p.setInt('freeze', fr - 1);
      } else {
        streak = 1;
      }
      await p.setInt('streak', streak);
      await p.setString('day', dayKey());
      await p.setInt('cnt', 0);
      cnt = 0;
    }
    cnt++;
    await p.setInt('cnt', cnt);
    final h = Map<String, dynamic>.from(jsonDecode(p.getString('hist') ?? '{}'));
    h[dayKey()] = cnt;
    await p.setString('hist', jsonEncode(h));
    final g = await Gam.record(cards: cards, goal: goal, cnt: cnt, streak: streak);
    xp = g.xp;
    freeze = g.freeze;
    if (mounted) setState(() => remDue = false);
    if (cnt == goal) syncNotif();
    if (!mounted) return;
    final notes = <String>[
      if (usedFreeze) '❄️ تم استخدام تجميد السلسلة، سلسلتك محفوظة',
      if (g.levelUp) '⬆️ وصلت إلى المستوى ${g.level}',
      for (final b in g.newBadges) '🏅 شارة جديدة: ${b.title}',
    ];
    if (notes.isNotEmpty) toast(notes.join('\n'));
    if (cnt == goal) showCelebration(context, streak: streak, cnt: cnt, goal: goal);
  }

  Future<void> aiFill(bool ex) async {
    final w = wC.text.trim();
    if (w.isEmpty) {
      setState(() { msg = 'اكتب الكلمة أولًا'; err = true; });
      return;
    }
    setState(() => busy = true);
    try {
      if (ex) { eC.text = await aiExample(w); } else { tC.text = await aiTranslate(w); }
      msg = '';
    } catch (e) { msg = '$e'; err = true; }
    if (mounted) setState(() => busy = false);
  }

  Future<void> lookupDict() async {
    final w = wC.text.trim();
    if (w.isEmpty) {
      setState(() { msg = 'اكتب الكلمة أولًا'; err = true; });
      return;
    }
    if (lang != 'en-US') {
      setState(() { msg = 'التعريف التلقائي متاح للإنجليزية فقط'; err = true; });
      return;
    }
    setState(() => busy = true);
    try {
      final d = await dictLookup(w);
      if (d == null) {
        msg = 'لم أجد تعريفًا لهذه الكلمة';
        err = true;
      } else {
        xC.text = d.note();
        if (eC.text.trim().isEmpty && d.example.isNotEmpty) eC.text = d.example;
        msg = 'تمت إضافة التعريف والنطق';
        err = false;
      }
    } catch (_) {
      msg = 'تعذر الاتصال بالقاموس';
      err = true;
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> autoImg() async {
    final w = wC.text.trim();
    if (w.isEmpty) {
      setState(() { msg = 'اكتب الكلمة أولًا'; err = true; });
      return;
    }
    setState(() => busy = true);
    try {
      final path = await fetchWikiImage(w, lang: lang.substring(0, 2));
      if (path == null) {
        msg = 'لم أجد صورة مناسبة لهذه الكلمة';
        err = true;
      } else {
        pickedImg = path;
        msg = 'تمت إضافة صورة للكلمة';
        err = false;
      }
    } catch (_) {
      msg = 'تعذر جلب الصورة';
      err = true;
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> genTopic() async {
    final tc = TextEditingController();
    var n = 15;
    final ok = await showDialog<bool>(
        context: context,
        builder: (_) => StatefulBuilder(
            builder: (ctx, setD) => AlertDialog(
                  title: const Text('توليد بطاقات بالذكاء الاصطناعي'),
                  content: Column(mainAxisSize: MainAxisSize.min, children: [
                    TextField(controller: tc, autofocus: true, decoration: const InputDecoration(hintText: 'الموضوع: السفر، المطبخ، الأعمال...')),
                    const SizedBox(height: 12),
                    Text('العدد: $n'),
                    Slider(value: n.toDouble(), min: 5, max: 30, divisions: 5, onChanged: (v) => setD(() => n = v.round())),
                  ]),
                  actions: [TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('توليد'))],
                )));
    if (ok != true || tc.text.trim().isEmpty) return;
    setState(() {
      busy = true;
      msg = '';
    });
    try {
      final t = await aiCards(tc.text.trim(), n);
      final old = bC.text.trim();
      bC.text = old.isEmpty ? t : '$old\n$t';
      msg = 'تم التوليد، راجع القائمة ثم اضغط إنشاء البطاقات';
      err = false;
    } catch (e) {
      msg = '$e';
      err = true;
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> fillBulk() async {
    setState(() => busy = true);
    final out = <String>[];
    try {
      for (final raw in bC.text.split('\n')) {
        final l = raw.trim();
        if (l.isEmpty) continue;
        out.add(l.contains(RegExp(r'[,،]')) ? l : '$l, ${await aiTranslate(l)}');
      }
      bC.text = out.join('\n');
      msg = 'تمت الترجمة، راجعها ثم اضغط إنشاء البطاقات';
      err = false;
    } catch (e) { msg = '$e'; err = true; }
    if (mounted) setState(() => busy = false);
  }

  Future<void> pickImg() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 600, imageQuality: 70);
    if (x == null) return;
    final dir = await getApplicationDocumentsDirectory();
    final f = await File(x.path).copy('${dir.path}/${newId()}.jpg');
    setState(() => pickedImg = f.path);
  }

  Future<void> editCard(Flash c) async {
    final a = TextEditingController(text: c.w), b = TextEditingController(text: c.t), e = TextEditingController(text: c.e);
    final x = TextEditingController(text: c.x);
    final ok = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
              title: const Text('تعديل البطاقة'),
              content: SingleChildScrollView(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                TextField(controller: a, textDirection: TextDirection.ltr),
                TextField(controller: b),
                TextField(controller: e, textDirection: TextDirection.ltr, decoration: const InputDecoration(hintText: 'مثال')),
                TextField(controller: x, minLines: 1, maxLines: 4, decoration: const InputDecoration(hintText: 'تعريف / ملاحظات')),
              ])),
              actions: [TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('حفظ'))],
            ));
    if (ok == true && a.text.trim().isNotEmpty && b.text.trim().isNotEmpty) {
      setState(() { c.w = a.text.trim(); c.t = b.text.trim(); c.e = e.text.trim(); c.x = x.text.trim(); });
      save();
    }
  }

  Future<void> renameDeck() async {
    final c = TextEditingController(text: deck);
    final n = await showDialog<String>(
        context: context,
        builder: (_) => AlertDialog(
              title: const Text('اسم جديد للمجموعة'),
              content: TextField(controller: c, autofocus: true),
              actions: [TextButton(onPressed: () => Navigator.pop(context, c.text.trim()), child: const Text('حفظ'))],
            ));
    if (n == null || n.isEmpty) return;
    setState(() { for (final x in cards.where((x) => x.d == deck)) { x.d = n; } deck = n; });
    save();
  }

  Future<void> deleteDeck() async {
    final ok = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
              title: Text('حذف مجموعة «$deck» وبطاقاتها؟'),
              actions: [
                TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
                TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف')),
              ],
            ));
    if (ok != true) return;
    setState(() { cards.removeWhere((x) => x.d == deck); deck = 'الكل'; });
    save();
  }

  String newId() => DateTime.now().microsecondsSinceEpoch.toString();

  void go(int t) => setState(() {
        tab = t;
        msg = '';
        if (t == 2) {
          idx = 0;
          all = false;
          hard = false;
          flip = false;
        }
      });

  void addOne() {
    final w = wC.text.trim(), t = tC.text.trim();
    if (w.isEmpty || t.isEmpty) {
      setState(() {
        msg = 'اكتب الكلمة وترجمتها.';
        err = true;
      });
      return;
    }
    cards.add(Flash(newId(), w, t, e: eC.text.trim(), d: curDeck, img: pickedImg, x: xC.text.trim()));
    save();
    wC.clear();
    tC.clear();
    eC.clear();
    xC.clear();
    setState(() {
      pickedImg = '';
      msg = 'تمت إضافة «$w»';
      err = false;
    });
  }

  void addBulk() {
    var ok = 0, bad = 0;
    for (final raw in bC.text.split('\n')) {
      final l = raw.trim();
      if (l.isEmpty) continue;
      final m = l.indexOf(RegExp(r'[,،]'));
      if (m < 1 || l.substring(m + 1).trim().isEmpty) {
        bad++;
        continue;
      }
      cards.add(Flash(newId() + '$ok', l.substring(0, m).trim(),
          l.substring(m + 1).trim(), d: curDeck));
      ok++;
    }
    if (ok == 0) {
      setState(() {
        msg = 'لا توجد أسطر صحيحة. استخدم الصيغة: كلمة، ترجمة';
        err = true;
      });
      return;
    }
    save();
    bC.clear();
    setState(() {
      msg = 'تمت إضافة $ok بطاقة' + (bad > 0 ? ' (تم تجاهل $bad سطر)' : '');
      err = false;
    });
  }

  void step(int d) => setState(() {
        final n = view.where((c) => all || c.isDue).length;
        idx = n == 0 ? 0 : (idx + d + n) % n;
        flip = false;
      });

  @override
  Widget build(BuildContext context) {
    final pages = [homeP(), addP(), studyP(), listP()];
    return Scaffold(
      body: SafeArea(
        child: Column(children: [
          Expanded(
              child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(18, 20, 18, 16),
                  child: pages[[0, 3, 2, 1][tab]])),
          navBar(),
        ]),
      ),
    );
  }

  Widget navBar() {
    const labels = ['الرئيسية', 'إضافة', 'حفظ', 'البطاقات'];
    const order = [0, 3, 2, 1];
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 6, 14, 10),
      child: Row(
        children: List.generate(4, (i) {
          final on = tab == order[i];
          return Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: OutlinedButton(
                onPressed: () => go(order[i]),
                style: OutlinedButton.styleFrom(
                  backgroundColor: on ? ink : Colors.white,
                  foregroundColor: on ? Colors.white : ink,
                  side: const BorderSide(color: ink, width: 2.5),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18)),
                ),
                child: Text(labels[i],
                    style: const TextStyle(
                        fontWeight: FontWeight.w800, fontSize: 14)),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget title(String s) => Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Text(s,
          style: const TextStyle(
              fontSize: 28, fontWeight: FontWeight.w900, height: 1.25)));

  Widget tile(Color c, int n, String l) => Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(20),
        decoration:
            BoxDecoration(color: c, borderRadius: BorderRadius.circular(28)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('$n',
              style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w900)),
          Text(l, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
        ]),
      );

  Widget btn(String s, VoidCallback f, {bool ghost = false}) => SizedBox(
        width: double.infinity,
        child: FilledButton(
          onPressed: f,
          style: FilledButton.styleFrom(
            backgroundColor: ghost ? Colors.white : ink,
            foregroundColor: ghost ? ink : Colors.white,
            side: ghost ? const BorderSide(color: ink, width: 2.5) : null,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          ),
          child: Text(s,
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        ),
      );

  Widget homeP() {
    final known = cards.where((c) => c.k).length;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      title('أهلاً، لنحفظ كلمات جديدة'),
      deckBar(),
      if (remDue) ReminderBanner(cnt: cnt, goal: goal),
      if (cards.isEmpty) const EmptyState(kind: Ill.books, title: 'ابدأ رحلتك', sub: 'أضف أول بطاقة لتبدأ الحفظ'),
      tile(mint, view.length, 'بطاقة في مجموعتك'),
      tile(lilac, known, 'كلمة حفظتها'),
      tile(mint, cnt, 'من هدفك اليومي ($goal) · سلسلة $streak يوم 🔥'),
      tile(peri, view.where((c) => c.isDue).length, 'مستحقة للمراجعة الآن'),
      tile(pinkC, Gam.levelOf(xp), 'مستواك · $xp نقطة خبرة' + (freeze > 0 ? ' · ❄️ $freeze تجميد' : '')),
      cards.isEmpty
          ? btn('أضف أول بطاقة', () => go(3))
          : btn('ابدأ الحفظ', () => go(2)),
      const SizedBox(height: 18),
      homeGrid(),
      const MotivCard(),
      const SizedBox(height: 10),
      btn('الإعدادات', () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsPage())); load(); }, ghost: true),
    ]);
  }

  void push(Widget w) => Navigator.push(context, MaterialPageRoute(builder: (_) => w));

  void pickDeck() => showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
          child: ListView(shrinkWrap: true, children: [
        for (final d in decks)
          ListTile(
              title: Text(d),
              onTap: () {
                Navigator.pop(context);
                setState(() => deck = d);
                go(1);
              }),
      ])));

  Future<void> toggleDark() async {
    final p = await SharedPreferences.getInstance();
    darkN.value = !darkN.value;
    await p.setBool('dark', darkN.value);
  }

  Widget homeGrid() => GridView.count(
        crossAxisCount: 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: .92,
        children: [
          HomeGridCard(label: 'ابدأ دراستك الآن', kind: Ill.student, onTap: () => go(2)),
          HomeGridCard(label: 'مذاكرة بذكاء', kind: Ill.bulb, onTap: () => go(3)),
          HomeGridCard(label: 'المواد الدراسية', kind: Ill.books, onTap: pickDeck),
          HomeGridCard(label: 'اختبارات وتقييمات', kind: Ill.quiz, onTap: () => push(QuizPage(cards: view))),
          HomeGridCard(label: 'تعلّم بذكاء', kind: Ill.brain, onTap: () => push(MatchPage(cards: view))),
          HomeGridCard(label: 'دروس متنوعة', kind: Ill.lessons, onTap: () => push(TypePage(cards: view))),
          HomeGridCard(label: 'تعليم بأسلوب عصري', kind: Ill.phone, onTap: () => push(ListenPage(cards: view))),
          HomeGridCard(label: 'تتبع تقدمك', kind: Ill.chart, onTap: () => push(StatsPage(cards: cards))),
          HomeGridCard(label: 'حقق أهدافك', kind: Ill.target, onTap: () async { await push2(const SettingsPage()); }),
          HomeGridCard(label: 'أنجز واستمر', kind: Ill.trophy, onTap: () => push(ProgressPage(cards: cards, goal: goal))),
          HomeGridCard(label: 'إدارة المهام', kind: Ill.tasks, onTap: () => push(const TasksPage())),
          HomeGridCard(label: 'خطط لوقتك', kind: Ill.calendar, onTap: () => push(const PlannerPage())),
          HomeGridCard(label: 'ركّز في دراستك', kind: Ill.focus, onTap: () => push(const FocusPage())),
          HomeGridCard(label: 'ملاحظاتك دائمًا', kind: Ill.notes, onTap: () => push(const NotesPage())),
          HomeGridCard(label: 'تنبيهات ومواعيد', kind: Ill.bell, onTap: () async { await push2(const RemindersPage()); }),
          HomeGridCard(label: 'وضع الليل', kind: Ill.moon, onTap: toggleDark),
          HomeGridCard(
              label: 'مزامنة بين أجهزتك',
              kind: Ill.cloud,
              onTap: () => push(SyncPage(getCards: () => cards, onSynced: (l) { setState(() => cards = l); save(); }))),
          HomeGridCard(
              label: 'نسخ واستيراد وتصدير',
              kind: Ill.books,
              onTap: () => push(BackupPage(cards: cards, onImport: (l) { setState(() => cards.addAll(l)); save(); }))),
          HomeGridCard(label: 'الكلمات الصعبة (${view.where((c) => c.isHard).length})', kind: Ill.brain, onTap: startHard),
          HomeGridCard(label: 'تحدي 60 ثانية', kind: Ill.focus, onTap: () => push(SprintPage(cards: view))),
          HomeGridCard(label: 'أكمل الجملة', kind: Ill.lessons, onTap: () => push(ClozePage(cards: view))),
          HomeGridCard(label: 'مسح كلمات من صورة', kind: Ill.phone, onTap: () => push(OcrPage(existing: cards, deck: curDeck, onAdd: addScanned))),
        ],
      );

  Future<void> push2(Widget w) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => w));
    load();
  }

  InputDecoration deco(String h) => InputDecoration(
        hintText: h,
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.all(14),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: ink, width: 2.5)),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: lilac, width: 3)),
      );

  Widget lbl(String s) => Padding(
      padding: const EdgeInsets.only(top: 12, bottom: 6),
      child: Text(s, style: const TextStyle(fontWeight: FontWeight.w700)));

  Widget seg() => Container(
        padding: const EdgeInsets.all(5),
        margin: const EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
            color: Colors.white, borderRadius: BorderRadius.circular(18)),
        child: Row(children: [
          for (final e in {'يدوي': false, 'كلمة، ترجمة': true}.entries)
            Expanded(
              child: GestureDetector(
                onTap: () => setState(() {
                  bulk = e.value;
                  msg = '';
                }),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                      color: bulk == e.value ? peri : Colors.transparent,
                      borderRadius: BorderRadius.circular(14)),
                  child: Text(e.key,
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                ),
              ),
            ),
        ]),
      );

  Widget msgW() => Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Text(msg,
          style: TextStyle(
              fontWeight: FontWeight.w700,
              color: err ? Colors.red.shade700 : const Color(0xFF0A7A45))));

  Widget addP() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        title('إضافة بطاقات'),
        deckBar(),
        seg(),
        if (!bulk) ...[
          lbl('الكلمة'),
          TextField(
              controller: wC,
              textDirection: TextDirection.ltr,
              decoration: deco('squash')),
          lbl('الترجمة'),
          TextField(controller: tC, decoration: deco('يسحق')),
          Wrap(children: [
            TextButton(onPressed: busy ? null : () => aiFill(false), child: const Text('ترجمة تلقائية ✨')),
            TextButton(onPressed: busy ? null : () => aiFill(true), child: const Text('مثال ✨')),
            TextButton(onPressed: busy ? null : lookupDict, child: const Text('تعريف ونطق 📖')),
            TextButton(onPressed: busy ? null : autoImg, child: const Text('صورة تلقائية 🖼️')),
          ]),
          lbl('مثال (اختياري)'),
          TextField(
              controller: eC,
              textDirection: TextDirection.ltr,
              decoration: deco("Don't squash the box")),
          lbl('تعريف / ملاحظات (اختياري)'),
          TextField(controller: xC, minLines: 1, maxLines: 4, textDirection: TextDirection.ltr, decoration: deco('/skwɒʃ/ (verb) to press flat')),
          TextButton.icon(
              onPressed: pickImg,
              icon: const Icon(Icons.image_outlined),
              label: Text(pickedImg.isEmpty ? 'إضافة صورة' : 'تم اختيار صورة ✓')),
          msgW(),
          btn('حفظ البطاقة', addOne),
        ] else ...[
          const Text('اكتب كل كلمة في سطر، وافصل بينها وبين ترجمتها بفاصلة.',
              style: TextStyle(color: sub, height: 1.6)),
          const SizedBox(height: 12),
          TextField(
              controller: bC,
              minLines: 8,
              maxLines: 14,
              textDirection: TextDirection.ltr,
              decoration: deco('apple, تفاحة\nbook, كتاب\nsquash, يسحق')),
          Wrap(children: [
            TextButton(onPressed: busy ? null : fillBulk, child: Text(busy ? 'جارٍ العمل...' : 'ترجمة الكلمات التي بلا ترجمة ✨')),
            TextButton(onPressed: busy ? null : genTopic, child: const Text('توليد بطاقات عن موضوع ✨')),
          ]),
          msgW(),
          btn('إنشاء البطاقات', addBulk),
        ],
      ]);

  Widget studyP() {
    final cards = view.where((c) => hard ? c.isHard : (all || c.isDue)).toList();
    if (hard && cards.isEmpty) {
      return Column(children: [
        const SizedBox(height: 40),
        const Text('لا توجد كلمات صعبة الآن 👏', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        const SizedBox(height: 16),
        btn('رجوع', () => go(0)),
      ]);
    }
    if (cards.isEmpty && view.isNotEmpty) {
      return Column(children: [
        const SizedBox(height: 40),
        const Text('أنهيت مراجعة اليوم 🎉', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        const SizedBox(height: 16),
        btn('راجع الكل', () => setState(() => all = true)),
      ]);
    }
    if (cards.isEmpty) {
      return Column(children: [
        const SizedBox(height: 40),
        const Text('لا توجد بطاقات للحفظ',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
        const SizedBox(height: 16),
        btn('إضافة بطاقات', () => go(1)),
      ]);
    }
    if (idx >= cards.length) idx = cards.length - 1;
    final c = cards[idx];
    final n = cards.length;
    return Column(children: [
      Row(children: [
        Expanded(
          child: Container(
            height: 46,
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(16)),
            clipBehavior: Clip.antiAlias,
            child: Stack(children: [
              FractionallySizedBox(
                  widthFactor: (idx + 1) / n,
                  child: Container(color: peri.withOpacity(.75))),
              Align(
                  alignment: Alignment.centerRight,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    child: Text('الخطوة ${idx + 1}/$n',
                        style: const TextStyle(fontWeight: FontWeight.w800)),
                  )),
            ]),
          ),
        ),
        const SizedBox(width: 10),
        InkWell(
          onTap: () => go(0),
          child: Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(16)),
              child: const Icon(Icons.close)),
        ),
      ]),
      const SizedBox(height: 14),
      GestureDetector(
        onTap: () => setState(() => flip = !flip),
        child: Container(
          width: double.infinity,
          constraints: const BoxConstraints(minHeight: 340),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
              color: Colors.white, borderRadius: BorderRadius.circular(28)),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Container(
              height: 170,
              clipBehavior: Clip.antiAlias,
              width: double.infinity,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  color: flip ? mint : pinkC,
                  borderRadius: BorderRadius.circular(80)),
              child: (c.img.isNotEmpty && !flip && File(c.img).existsSync())
                  ? darkWrap(darkN.value, Image.file(File(c.img), fit: BoxFit.cover, width: double.infinity, height: 170))
                  : Text(flip ? 'ع' : c.w.characters.first.toUpperCase(),
                  style: const TextStyle(fontSize: 64, fontWeight: FontWeight.w900)),
            ),
            const SizedBox(height: 16),
            if (flip) ...[
              Text(c.t,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800)),
              if (c.e.isNotEmpty)
                Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Text(c.e,
                        textDirection: TextDirection.ltr,
                        style: const TextStyle(color: sub, fontSize: 15))),
              if (c.x.isNotEmpty)
                Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Text(c.x,
                        textAlign: TextAlign.center,
                        textDirection: TextDirection.ltr,
                        style: const TextStyle(color: sub, fontSize: 13, height: 1.5))),
            ] else ...[
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Flexible(
                    child: Text(c.w,
                        textDirection: TextDirection.ltr,
                        style: const TextStyle(
                            fontSize: 34, fontWeight: FontWeight.w800))),
                const SizedBox(width: 10),
                IconButton.filled(
                    style: IconButton.styleFrom(backgroundColor: ink),
                    onPressed: () => tts.speak(c.w),
                    icon: const Icon(Icons.volume_up, size: 18)),
              ]),
              const SizedBox(height: 8),
              const Text('اضغط لرؤية الترجمة',
                  style: TextStyle(color: sub, fontSize: 13)),
              if (c.lp >= 4)
                const Padding(
                    padding: EdgeInsets.only(top: 6),
                    child: Text('🔥 كلمة عنيدة', style: TextStyle(color: sub, fontSize: 12))),
            ],
          ]),
        ),
      ),
      const SizedBox(height: 10),
      Row(children: [
        navB(Icons.chevron_right, () => step(-1)),
        const SizedBox(width: 8),
        navB(Icons.chevron_left, () => step(1)),
      ]),
      const SizedBox(height: 12),
      Row(children: [
        for (final g in [['صعبة', 0], ['جيدة', 1], ['سهلة', 2]])
          Expanded(
              child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 3),
                  child: btn(g[0] as String, () {
                    setState(() {
                      c.grade(g[1] as int);
                      flip = false;
                      if (all) idx = (idx + 1) % n;
                    });
                    save();
                    logReview();
                  }, ghost: true))),
      ]),
    ]);
  }

  Widget navB(IconData i, VoidCallback f) => Expanded(
        child: InkWell(
          onTap: f,
          child: Container(
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(16)),
              child: Icon(i, size: 28)),
        ),
      );

  Widget listP() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        title('البطاقات (${view.length})'),
        deckBar(),
        TextField(onChanged: (s) => setState(() => q = s), decoration: deco('بحث')),
        const SizedBox(height: 8),
        Wrap(spacing: 8, children: [
          FilterChip(label: const Text('⭐ المفضلة'), selected: fav, onSelected: (v) => setState(() => fav = v)),
          FilterChip(label: const Text('🔥 الصعبة'), selected: hardF, onSelected: (v) => setState(() => hardF = v)),
          if (deck != 'الكل') ActionChip(label: const Text('إعادة تسمية'), onPressed: renameDeck),
          if (deck != 'الكل') ActionChip(label: const Text('حذف المجموعة'), onPressed: deleteDeck),
        ]),
        const SizedBox(height: 12),
        if (cards.isEmpty)
          const Padding(
              padding: EdgeInsets.all(30),
              child: Center(
                  child: Text('لا توجد بطاقات بعد.\nأضف كلمات يدويًا أو ألصق قائمة.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: sub, height: 1.8)))),
        for (final c in view.where((c) => (!fav || c.f) && (!hardF || c.isHard) && (q.isEmpty || c.w.toLowerCase().contains(q.toLowerCase()) || c.t.contains(q))))
          Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(20)),
            child: Row(children: [
              Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: c.k ? mint : ink.withOpacity(.2))),
              const SizedBox(width: 12),
              Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(c.lp >= 4 ? '${c.w} 🔥' : c.w,
                    textDirection: TextDirection.ltr,
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                Text(c.t, style: const TextStyle(color: sub)),
              ])),
              IconButton(
                  onPressed: () { setState(() => c.f = !c.f); save(); },
                  icon: Icon(c.f ? Icons.star : Icons.star_border, color: c.f ? const Color(0xFFF6B800) : sub)),
              IconButton(onPressed: () => editCard(c), icon: const Icon(Icons.edit_outlined, color: sub)),
              IconButton(
                  onPressed: () {
                    setState(() => cards.remove(c));
                    save();
                  },
                  icon: const Icon(Icons.close, color: sub)),
            ]),
          ),
        if (cards.isNotEmpty)
          btn('حذف الكل', () {
            setState(() => cards.clear());
            save();
          }, ghost: true),
      ]);
}
