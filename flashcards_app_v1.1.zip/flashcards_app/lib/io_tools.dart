import 'dart:convert';
import 'models.dart';

String _plain(String s) => s
    .replaceAll(RegExp(r'<[^>]*>'), ' ')
    .replaceAll('&nbsp;', ' ')
    .replaceAll('&lt;', '<')
    .replaceAll('&gt;', '>')
    .replaceAll('&amp;', '&')
    .replaceAll(RegExp(r'\s+'), ' ')
    .trim();

final _br = RegExp(r'<br\s*/?>', caseSensitive: false);

List<List<String>> _rows(String t, String d) {
  final rows = <List<String>>[];
  var row = <String>[];
  final f = StringBuffer();
  var inQ = false;
  for (var i = 0; i < t.length; i++) {
    final ch = t[i];
    if (inQ) {
      if (ch == '"') {
        if (i + 1 < t.length && t[i + 1] == '"') {
          f.write('"');
          i++;
        } else {
          inQ = false;
        }
      } else {
        f.write(ch);
      }
    } else if (ch == '"' && f.isEmpty) {
      inQ = true;
    } else if (ch == d) {
      row.add(f.toString());
      f.clear();
    } else if (ch == '\n' || ch == '\r') {
      if (ch == '\r' && i + 1 < t.length && t[i + 1] == '\n') i++;
      row.add(f.toString());
      f.clear();
      rows.add(row);
      row = <String>[];
    } else {
      f.write(ch);
    }
  }
  if (f.isNotEmpty || row.isNotEmpty) {
    row.add(f.toString());
    rows.add(row);
  }
  return rows;
}

/// يقرأ أي صيغة مدعومة: JSON (قائمة أو {cards:[...]})، CSV، TSV، تصدير Anki النصي، أو أسطر «كلمة، ترجمة».
List<Flash> parseAnyCards(String raw) {
  final t = raw.replaceFirst('\uFEFF', '').trim();
  if (t.isEmpty) return [];
  final base = DateTime.now().microsecondsSinceEpoch;
  final out = <Flash>[];

  if (t.startsWith('[') || t.startsWith('{')) {
    final j = jsonDecode(t);
    final list = j is List ? j : (j is Map && j['cards'] is List ? j['cards'] as List : <dynamic>[]);
    for (final e in list) {
      final f = Flash.fromJson(Map<String, dynamic>.from(e as Map));
      f.id = '${base}_${out.length}';
      f.mt = 0;
      out.add(f);
    }
    return out;
  }

  final anki = t.startsWith('#separator') || t.contains('\n#tags column');
  final lines = t.split(RegExp(r'\r?\n')).where((l) => l.trim().isNotEmpty && !l.startsWith('#')).toList();
  if (lines.isEmpty) return [];

  var d = '';
  if (t.contains('#separator:comma')) d = ',';
  if (t.contains('#separator:semicolon')) d = ';';
  if (t.contains('#separator:tab')) d = '\t';
  if (d.isEmpty) {
    var best = 0;
    for (final c in ['\t', ',', ';', '،']) {
      final n = lines.first.split(c).length - 1;
      if (n > best) {
        best = n;
        d = c;
      }
    }
    if (d.isEmpty) return [];
  }

  final rows = _rows(t, d).where((r) => r.isNotEmpty && !r[0].startsWith('#') && r.any((c) => c.trim().isNotEmpty)).toList();
  if (rows.isEmpty) return [];

  final h = rows.first.map((s) => s.trim().toLowerCase()).toList();
  final isHead = const ['word', 'front', 'الكلمة', 'كلمة', 'term'].contains(h[0]);
  int idx(List<String> names) {
    for (var i = 0; i < h.length; i++) {
      if (names.contains(h[i])) return i;
    }
    return -1;
  }

  var wi = 0, ti = 1, ei = -1, di = -1, ni = -1;
  if (isHead) {
    ti = idx(['translation', 'back', 'الترجمة', 'ترجمة', 'meaning']);
    ei = idx(['example', 'مثال']);
    di = idx(['deck', 'المجموعة', 'مجموعة', 'tags']);
    ni = idx(['notes', 'note', 'ملاحظات']);
  } else if (rows.first.length >= 3) {
    if (anki) {
      di = 2;
    } else {
      ei = 2;
    }
  }
  String cell(List<String> r, int i) => (i >= 0 && i < r.length) ? r[i].trim() : '';

  for (final r in rows.skip(isHead ? 1 : 0)) {
    final w = _plain(cell(r, wi));
    var tr = cell(r, ti);
    var e = cell(r, ei);
    if (_br.hasMatch(tr)) {
      final parts = tr.split(_br);
      tr = _plain(parts.first);
      if (e.isEmpty) e = _plain(parts.skip(1).join(' / '));
    } else {
      tr = _plain(tr);
    }
    if (w.isEmpty || tr.isEmpty) continue;
    var deck = cell(r, di).replaceAll('_', ' ');
    if (deck.isEmpty) deck = 'عام';
    out.add(Flash('${base}_${out.length}', w, tr, e: _plain(e), d: deck, x: cell(r, ni)));
  }
  return out;
}

String _q(String s) => (s.contains(',') || s.contains('"') || s.contains('\n') || s.contains('\r'))
    ? '"${s.replaceAll('"', '""')}"'
    : s;

/// CSV يفتحه Excel وGoogle Sheets (UTF-8 مع BOM ليظهر العربي صحيحًا)
String cardsToCsv(List<Flash> cs) =>
    '\uFEFFword,translation,example,deck,notes\n${cs.map((c) => [c.w, c.t, c.e, c.d, c.x].map(_q).join(',')).join('\n')}';

String _tab(String s) => s.replaceAll(RegExp(r'[\t\r\n]+'), ' ');
String _html(String s) => _tab(s).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');

/// ملف نصي بصيغة استيراد Anki (File ▸ Import): Front / Back / Tags
String cardsToAnki(List<Flash> cs) {
  final b = StringBuffer('#separator:tab\n#html:true\n#tags column:3\n');
  for (final c in cs) {
    final back = StringBuffer(_html(c.t));
    if (c.e.isNotEmpty) back.write('<br>${_html(c.e)}');
    if (c.x.isNotEmpty) back.write('<br>${_html(c.x)}');
    b.writeln('${_tab(c.w)}\t$back\t${c.d.replaceAll(RegExp(r'\s+'), '_')}');
  }
  return b.toString();
}
