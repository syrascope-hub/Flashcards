#!/usr/bin/env python3
"""يُشغَّل مرة واحدة بعد `flutter create .` من جذر المشروع:
    python3 tools/setup_android.py
يضيف: إذن الإنترنت (مهم لنسخة release)، إذن الإشعارات، مستقبلات الجدولة بعد إعادة التشغيل،
وتفعيل core library desugaring المطلوب لمكتبة الإشعارات، وأوصاف أذونات iOS للكاميرا والصور.
السكربت آمن للتشغيل أكثر من مرة."""
import os, re, sys

root = os.getcwd()
done = []

# ---------- AndroidManifest ----------
mf = os.path.join(root, 'android/app/src/main/AndroidManifest.xml')
if os.path.exists(mf):
    s = open(mf, encoding='utf-8').read()
    perms = ['android.permission.INTERNET', 'android.permission.POST_NOTIFICATIONS',
             'android.permission.RECEIVE_BOOT_COMPLETED', 'android.permission.VIBRATE']
    add = ''.join(f'    <uses-permission android:name="{p}"/>\n' for p in perms if p not in s)
    if add:
        s = re.sub(r'(\s*)<application', lambda m: '\n' + add.rstrip('\n') + m.group(1) + '<application', s, count=1)
        done.append('أذونات AndroidManifest')
    if 'ScheduledNotificationReceiver' not in s:
        recv = '''
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
    '''
        s = s.replace('</application>', recv + '</application>', 1)
        done.append('مستقبلات الإشعارات')
    open(mf, 'w', encoding='utf-8').write(s)
else:
    print('! لم أجد AndroidManifest.xml. شغّل `flutter create .` أولًا.')

# ---------- Gradle (desugaring) ----------
for name, kts in (('build.gradle.kts', True), ('build.gradle', False)):
    gp = os.path.join(root, 'android/app', name)
    if not os.path.exists(gp):
        continue
    g = open(gp, encoding='utf-8').read()
    if 'oreLibraryDesugaring' in g:
        break
    flag = 'isCoreLibraryDesugaringEnabled = true' if kts else 'coreLibraryDesugaringEnabled true'
    dep = ('    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n' if kts
           else "    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'\n")
    if 'compileOptions {' in g:
        g = g.replace('compileOptions {', 'compileOptions {\n        ' + flag, 1)
    else:
        print('! لم أجد compileOptions في', name, '— أضف', flag, 'يدويًا')
    m = re.search(r'^dependencies\s*\{', g, flags=re.M)
    if m:
        g = g[:m.end()] + '\n' + dep.rstrip('\n') + g[m.end():]
    else:
        g += '\ndependencies {\n' + dep + '}\n'
    open(gp, 'w', encoding='utf-8').write(g)
    done.append('desugaring في ' + name)
    break
else:
    print('! لم أجد build.gradle(.kts) في android/app')

# ---------- iOS Info.plist ----------
ip = os.path.join(root, 'ios/Runner/Info.plist')
if os.path.exists(ip):
    p = open(ip, encoding='utf-8').read()
    keys = {'NSCameraUsageDescription': 'لتصوير الكلمات واستخراجها كبطاقات',
            'NSPhotoLibraryUsageDescription': 'لاختيار صور للبطاقات أو لاستخراج الكلمات منها'}
    add = ''.join(f'\t<key>{k}</key>\n\t<string>{v}</string>\n' for k, v in keys.items() if k not in p)
    if add:
        p = p.replace('</dict>\n</plist>', add + '</dict>\n</plist>', 1)
        open(ip, 'w', encoding='utf-8').write(p)
        done.append('أوصاف أذونات iOS')

print('تم:' if done else 'لا شيء لتغييره (الإعداد مكتمل).', *done, sep='\n - ' if done else '')
