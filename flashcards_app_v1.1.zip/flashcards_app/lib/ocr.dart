import 'package:flutter/material.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image_picker/image_picker.dart';
import 'ai.dart';
import 'models.dart';
import 'ui.dart';

/// يقرأ النص من صورة (كتاب، لافتة، ورقة) ويقترح كلماته لإضافتها كبطاقات.
/// ملاحظة: القراءة تدعم اللغات المكتوبة بالأحرف اللاتينية.
class OcrPage extends StatefulWidget {
  final List<Flash> existing;
  final String deck;
  final void Function(List<Flash>) onAdd;
  const OcrPage({super.key, required this.existing, required this.deck, required this.onAdd});
  @override
  State<OcrPage> createState() => _OcrState();
}

class _OcrState extends State<OcrPage> {
  List<String> words = [];
  final Set<String> sel = {};
  bool busy = false;
  String msg = '';

  static const _stop = {
    'the', 'and', 'for', 'are', 'but', 'not', 'you', 'all', 'can', 'her', 'was', 'one', 'our', 'out', 'had', 'has',
    'his', 'how', 'its', 'who', 'did', 'get', 'she', 'him', 'may', 'that', 'with', 'this', 'from', 'have', 'they',
    'will', 'your', 'what', 'when', 'were', 'been', 'there', 'their', 'which', 'would', 'about', 'into', 'than',
    'then', 'them', 'these', 'those', 'also', 'some', 'such', 'only', 'other'
  };

  Future<void> scan(ImageSource s) async {
    final x = await ImagePicker().pickImage(source: s, imageQuality: 90, maxWidth: 1800);
    if (x == null) return;
    setState(() {
      busy = true;
      msg = '';
      words = [];
      sel.clear();
    });
    final rec = TextRecognizer(script: TextRecognitionScript.latin);
    try {
      final res = await rec.processImage(InputImage.fromFilePath(x.path));
      final have = widget.existing.map((c) => c.w.toLowerCase()).toSet();
      final seen = <String>{};
      final out = <String>[];
      for (final m in RegExp(r"[\p{L}][\p{L}'\-]{2,}", unicode: true).allMatches(res.text)) {
        final w = m.group(0)!.toLowerCase();
        if (_stop.contains(w) || have.contains(w) || !seen.add(w)) continue;
        out.add(w);
        if (out.length >= 150) break;
      }
      words = out;
      msg = out.isEmpty ? 'لم أجد كلمات جديدة في الصورة' : 'وجدت ${out.length} كلمة جديدة، اختر ما تريد إضافته (حتى 40)';
    } catch (_) {
      msg = 'تعذر قراءة الصورة';
    }
    await rec.close();
    if (mounted) setState(() => busy = false);
  }

  Future<void> addSel() async {
    final list = sel.toList();
    if (list.isEmpty) return;
    final messenger = ScaffoldMessenger.of(context);
    setState(() {
      busy = true;
      msg = '';
    });
    final out = <Flash>[];
    var failed = 0;
    final base = DateTime.now().microsecondsSinceEpoch;
    for (var i = 0; i < list.length; i++) {
      if (mounted) setState(() => msg = 'جارٍ الترجمة ${i + 1}/${list.length}');
      var t = '؟';
      if (failed < 2) {
        try {
          t = await aiTranslate(list[i]);
        } catch (_) {
          failed++;
        }
      }
      out.add(Flash('${base}_$i', list[i], t, d: widget.deck));
    }
    widget.onAdd(out);
    if (!mounted) return;
    Navigator.pop(context);
    messenger.showSnackBar(SnackBar(
        content: Text(failed > 0
            ? 'أُضيفت ${out.length} بطاقة. بعضها بلا ترجمة (؟) — أضف مفتاح Hugging Face ثم عدّلها'
            : 'أُضيفت ${out.length} بطاقة إلى «${widget.deck}»')));
  }

  @override
  Widget build(BuildContext context) => uiPage(
      'مسح كلمات من صورة',
      Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          Expanded(child: uiBtn('📷 كاميرا', busy ? null : () => scan(ImageSource.camera))),
          const SizedBox(width: 10),
          Expanded(child: uiBtn('🖼️ معرض', busy ? null : () => scan(ImageSource.gallery), c: Colors.white, fg: kInk)),
        ]),
        const SizedBox(height: 14),
        if (busy) const Center(child: Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator())),
        if (msg.isNotEmpty) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(msg, style: const TextStyle(fontWeight: FontWeight.w700, color: kSub))),
        if (words.isNotEmpty) ...[
          Wrap(spacing: 8, runSpacing: 4, textDirection: TextDirection.ltr, children: [
            for (final w in words)
              FilterChip(
                  label: Text(w),
                  selected: sel.contains(w),
                  onSelected: (v) => setState(() {
                        if (v) {
                          if (sel.length < 40) sel.add(w);
                        } else {
                          sel.remove(w);
                        }
                      })),
          ]),
          const SizedBox(height: 14),
          uiBtn('إضافة ${sel.length} كلمة (مع ترجمة تلقائية ✨)', busy || sel.isEmpty ? null : addSel),
        ],
        if (words.isEmpty && !busy && msg.isEmpty)
          const Padding(
              padding: EdgeInsets.all(20),
              child: Text('صوّر صفحة من كتاب أو لافتة أو ورقة، وسأستخرج لك الكلمات الجديدة لتضيفها كبطاقات.',
                  textAlign: TextAlign.center, style: TextStyle(color: kSub, height: 1.8))),
      ]));
}
