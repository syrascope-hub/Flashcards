import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'ai.dart';

/// إشعارات المراجعة اليومية. تُجدول 14 يومًا قدّامًا وتُعاد جدولتها كلما فُتح التطبيق،
/// وتُلغى إشعارات اليوم تلقائيًا عند بلوغ الهدف اليومي.
class Notif {
  static final FlutterLocalNotificationsPlugin _np = FlutterLocalNotificationsPlugin();
  static bool _ready = false;

  static const _details = NotificationDetails(
    android: AndroidNotificationDetails('review_daily', 'تذكير المراجعة',
        channelDescription: 'تذكير يومي لمراجعة بطاقات الحفظ', importance: Importance.high, priority: Priority.high),
    iOS: DarwinNotificationDetails(),
  );

  static const _bodies = [
    'بضع دقائق من المراجعة تكفي لتثبيت كلماتك 📚',
    'سلسلتك تنتظرك! راجع بطاقاتك اليوم 🔥',
    'خطوة صغيرة اليوم، حفظ أقوى غدًا ✨',
    'حان وقت مراجعة الكلمات المستحقة 🧠',
  ];

  static Future<void> init() async {
    if (_ready) return;
    tzdata.initializeTimeZones();
    try {
      final dynamic r = await FlutterTimezone.getLocalTimezone();
      final String name = r is String ? r : (r as dynamic).identifier as String;
      tz.setLocalLocation(tz.getLocation(name));
    } catch (_) {}
    const init = InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings(
          requestAlertPermission: false, requestBadgePermission: false, requestSoundPermission: false),
    );
    await _np.initialize(init);
    _ready = true;
  }

  /// يطلب إذن الإشعارات. يُرجع true إذا مُنح (أو لا يلزم).
  static Future<bool> requestPermission() async {
    await init();
    final a = _np.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    final i = _np.resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>();
    final ok1 = await a?.requestNotificationsPermission();
    final ok2 = await i?.requestPermissions(alert: true, badge: true, sound: true);
    return (ok1 ?? ok2 ?? true);
  }

  static Future<void> test() async {
    await init();
    await _np.show(1, 'بطاقات الحفظ', 'الإشعارات تعمل بنجاح ✅', _details);
  }

  static Future<void> sync(bool on, int h, int m, bool goalDone) async {
    await init();
    await _np.cancelAll();
    if (!on) return;
    final now = tz.TZDateTime.now(tz.local);
    for (var i = 0; i < 14; i++) {
      final t = tz.TZDateTime(tz.local, now.year, now.month, now.day + i, h, m);
      if (t.isBefore(now)) continue;
      if (i == 0 && goalDone) continue;
      await _np.zonedSchedule(100 + i, 'حان وقت المراجعة', _bodies[(t.day + i) % _bodies.length], t, _details,
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime);
    }
  }

  static Future<void> syncFromPrefs() async {
    final p = await SharedPreferences.getInstance();
    final goal = p.getInt('goal') ?? 20;
    final done = p.getString('day') == dayKey() && (p.getInt('cnt') ?? 0) >= goal;
    await sync(p.getBool('rem_on') ?? false, p.getInt('rem_h') ?? 20, p.getInt('rem_m') ?? 0, done);
  }
}
