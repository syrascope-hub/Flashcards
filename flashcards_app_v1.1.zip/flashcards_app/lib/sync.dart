import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'illustrations.dart';
import 'models.dart';
import 'secrets.dart';
import 'store.dart';
import 'ui.dart';

/// كود SQL يُنفَّذ مرة واحدة في Supabase (SQL Editor).
/// الجدول مغلق أمام الوصول المباشر، والمزامنة تتم عبر دالتين لا تعملان إلا برمزك السري.
const kSyncSql = '''
create table if not exists flashcards_sync (
  code text primary key,
  data text not null,
  updated_at timestamptz not null default now()
);
alter table flashcards_sync enable row level security;

create or replace function sync_get(p_code text) returns text
language sql security definer set search_path = public as \$\$
  select data from flashcards_sync where code = p_code
\$\$;

create or replace function sync_put(p_code text, p_data text) returns void
language plpgsql security definer set search_path = public as \$\$
begin
  insert into flashcards_sync(code, data, updated_at) values (p_code, p_data, now())
  on conflict (code) do update set data = excluded.data, updated_at = now();
end
\$\$;

grant execute on function sync_get(text), sync_put(text, text) to anon;
''';

class SyncCfg {
  String url, key, code;
  SyncCfg(this.url, this.key, this.code);
  bool get ok => url.startsWith('http') && key.isNotEmpty && code.length >= 12;

  static Future<SyncCfg> load() async =>
      SyncCfg((await Secrets.get('sync_url')).trim(), (await Secrets.get('sync_key')).trim(), (await Secrets.get('sync_code')).trim());

  Future<void> save() async {
    await Secrets.set('sync_url', url.trim().replaceAll(RegExp(r'/+$'), ''));
    await Secrets.set('sync_key', key.trim());
    await Secrets.set('sync_code', code.trim());
  }
}

class SyncResult {
  final List<Flash> cards;
  final int changed;
  SyncResult(this.cards, this.changed);
}

Future<dynamic> _rpc(SyncCfg c, String fn, Map<String, dynamic> args) async {
  final h = {'apikey': c.key, 'Content-Type': 'application/json'};
  if (c.key.startsWith('eyJ')) h['Authorization'] = 'Bearer ${c.key}';
  final r = await http
      .post(Uri.parse('${c.url.replaceAll(RegExp(r'/+$'), '')}/rest/v1/rpc/$fn'), headers: h, body: jsonEncode(args))
      .timeout(const Duration(seconds: 40));
  if (r.statusCode >= 300) {
    var m = utf8.decode(r.bodyBytes);
    if (m.length > 120) m = m.substring(0, 120);
    throw 'فشلت المزامنة (${r.statusCode}) $m';
  }
  final b = utf8.decode(r.bodyBytes).trim();
  return b.isEmpty ? null : jsonDecode(b);
}

/// دمج على مستوى البطاقة: الأحدث تعديلًا يفوز، والمحذوف لا يعود.
Future<SyncResult> runSync(List<Flash> Function() local) async {
  final cfg = await SyncCfg.load();
  if (!cfg.ok) throw 'أكمل إعدادات المزامنة أولًا (الرمز 12 حرفًا على الأقل)';
  final raw = await _rpc(cfg, 'sync_get', {'p_code': cfg.code});
  Map<String, dynamic> remote = {};
  if (raw is String && raw.isNotEmpty) remote = Map<String, dynamic>.from(jsonDecode(raw));
  final rc = [for (final e in (remote['cards'] as List? ?? [])) Flash.fromJson(Map<String, dynamic>.from(e as Map))];
  final dead = <String, int>{};
  for (final e in Map<String, dynamic>.from(remote['dead'] ?? {}).entries) {
    dead[e.key] = (e.value as num).toInt();
  }
  final ld = await Store.dead();
  for (final e in ld.entries) {
    if (e.value > (dead[e.key] ?? 0)) dead[e.key] = e.value;
  }

  final lc = local();
  final lmap = {for (final c in lc) c.id: c};
  final map = <String, Flash>{};
  for (final c in [...lc, ...rc]) {
    final cur = map[c.id];
    if (cur == null || c.mt > cur.mt) map[c.id] = c;
  }
  map.removeWhere((id, c) => dead.containsKey(id) && dead[id]! >= c.mt);
  final merged = map.values.toList();
  final changed = merged.where((c) => lmap[c.id] == null || lmap[c.id]!.mt < c.mt).length;

  await _rpc(cfg, 'sync_put', {
    'p_code': cfg.code,
    'p_data': jsonEncode({'v': 2, 'cards': merged.map((c) => c.toJson()).toList(), 'dead': dead})
  });
  await Store.setDead(dead);
  return SyncResult(merged, changed);
}

class SyncPage extends StatefulWidget {
  final List<Flash> Function() getCards;
  final void Function(List<Flash>) onSynced;
  const SyncPage({super.key, required this.getCards, required this.onSynced});
  @override
  State<SyncPage> createState() => _SyncState();
}

class _SyncState extends State<SyncPage> {
  final url = TextEditingController(), key = TextEditingController(), code = TextEditingController();
  bool auto = false, busy = false, err = false;
  String msg = '';

  @override
  void initState() {
    super.initState();
    SyncCfg.load().then((c) async {
      final p = await SharedPreferences.getInstance();
      if (!mounted) return;
      setState(() {
        url.text = c.url;
        key.text = c.key;
        code.text = c.code;
        auto = p.getBool('sync_auto') ?? false;
      });
    });
  }

  void genCode() {
    const a = 'abcdefghijklmnopqrstuvwxyz0123456789';
    final r = Random.secure();
    setState(() => code.text = List.generate(24, (_) => a[r.nextInt(a.length)]).join());
  }

  Future<void> syncNow() async {
    setState(() {
      busy = true;
      msg = '';
      err = false;
    });
    try {
      await SyncCfg(url.text, key.text, code.text).save();
      final res = await runSync(widget.getCards);
      widget.onSynced(res.cards);
      msg = 'تمت المزامنة ✅ · ${res.cards.length} بطاقة (${res.changed} محدّثة من السحابة)';
    } catch (e) {
      msg = '$e';
      err = true;
    }
    if (mounted) setState(() => busy = false);
  }

  Widget f(String l, TextEditingController c, {bool obscure = false, String? hint}) =>
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(padding: const EdgeInsets.only(top: 12, bottom: 6), child: Text(l, style: const TextStyle(fontWeight: FontWeight.w700))),
        TextField(controller: c, obscureText: obscure, textDirection: TextDirection.ltr, decoration: uiDeco(hint ?? '')),
      ]);

  @override
  Widget build(BuildContext context) => uiPage(
      'مزامنة بين أجهزتك',
      Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Center(child: Illo(Ill.cloud, size: 100)),
        const Text(
            'تتم المزامنة عبر مشروعك الخاص في Supabase (مجاني). بطاقاتك تُدمج بذكاء: آخر تعديل يفوز، والمحذوف لا يعود. الصور تبقى على جهازها ولا تُرفع.',
            style: TextStyle(color: kSub, height: 1.7)),
        f('رابط المشروع (Project URL)', url, hint: 'https://xxxx.supabase.co'),
        f('المفتاح العام (anon / publishable key)', key, obscure: true),
        f('رمز المزامنة السري (نفسه على كل أجهزتك)', code, hint: '24 حرفًا عشوائيًا'),
        Row(children: [
          TextButton(onPressed: genCode, child: const Text('توليد رمز عشوائي')),
          TextButton(
              onPressed: () {
                Clipboard.setData(ClipboardData(text: code.text));
                setState(() => msg = 'تم نسخ الرمز');
              },
              child: const Text('نسخ الرمز')),
        ]),
        SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('مزامنة تلقائية عند فتح التطبيق', style: TextStyle(fontWeight: FontWeight.w700)),
            value: auto,
            onChanged: (v) async {
              setState(() => auto = v);
              (await SharedPreferences.getInstance()).setBool('sync_auto', v);
            }),
        const SizedBox(height: 8),
        uiBtn(busy ? 'جارٍ المزامنة...' : 'مزامنة الآن', busy ? null : syncNow),
        if (msg.isNotEmpty)
          Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Text(msg, style: TextStyle(fontWeight: FontWeight.w700, color: err ? Colors.red.shade700 : const Color(0xFF0A7A45)))),
        uiHead('الإعداد لأول مرة'),
        const Text(
            '1) أنشئ مشروعًا مجانيًا في supabase.com\n'
            '2) من SQL Editor شغّل الكود الذي تنسخه بالزر أدناه\n'
            '3) من Project Settings ▸ API انسخ الرابط والمفتاح العام والصقهما هنا\n'
            '4) ولّد الرمز السري واستخدم الرمز نفسه على أجهزتك الأخرى',
            style: TextStyle(height: 1.9, color: kSub)),
        const SizedBox(height: 10),
        uiBtn('نسخ كود SQL', () {
          Clipboard.setData(const ClipboardData(text: kSyncSql));
          setState(() {
            msg = 'تم نسخ كود SQL، الصقه في Supabase ▸ SQL Editor';
            err = false;
          });
        }, c: Colors.white, fg: kInk),
        const SizedBox(height: 10),
        const Text('تنبيه: كل من يعرف رمزك يستطيع قراءة بطاقاتك، فلا تشاركه مع أحد. البيانات غير مشفّرة على الخادم.',
            style: TextStyle(color: kSub, height: 1.7, fontSize: 13)),
      ]));
}
