import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';
import 'ui.dart';

// ---------------- تحدي 60 ثانية ----------------
class SprintPage extends StatefulWidget {
  final List<Flash> cards;
  const SprintPage({super.key, required this.cards});
  @override
  State<SprintPage> createState() => _SprintState();
}

class _SprintState extends State<SprintPage> {
  final r = Random();
  Timer? timer;
  int left = 60, score = 0, best = 0, combo = 0, maxCombo = 0;
  bool running = false, over = false, newBest = false;
  Flash? cur;
  bool rev = false;
  List<String> opts = [];
  String? picked;

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      if (mounted) setState(() => best = p.getInt('sprint_best') ?? 0);
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  String ans() => rev ? cur!.w : cur!.t;

  void next() {
    cur = widget.cards[r.nextInt(widget.cards.length)];
    rev = r.nextBool();
    final a = ans();
    final pool = widget.cards.map((x) => rev ? x.w : x.t).where((s) => s != a).toSet().toList()..shuffle(r);
    opts = [a, ...pool.take(3)]..shuffle(r);
    picked = null;
  }

  void start() {
    timer?.cancel();
    setState(() {
      score = 0;
      combo = 0;
      maxCombo = 0;
      left = 60;
      over = false;
      newBest = false;
      running = true;
      next();
    });
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      setState(() {
        left--;
        if (left <= 0) finish();
      });
    });
  }

  void finish() {
    timer?.cancel();
    running = false;
    over = true;
    if (score > best) {
      best = score;
      newBest = true;
      SharedPreferences.getInstance().then((p) => p.setInt('sprint_best', score));
    }
  }

  void answer(String o) {
    if (picked != null || !running) return;
    setState(() {
      picked = o;
      if (o == ans()) {
        score++;
        combo++;
        if (combo > maxCombo) maxCombo = combo;
      } else {
        combo = 0;
        left = max(0, left - 3); // عقوبة 3 ثوانٍ للخطأ
        if (left <= 0) finish();
      }
    });
    Future.delayed(const Duration(milliseconds: 400), () {
      if (mounted && running) setState(next);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (widget.cards.length < 4) {
      return uiPage('تحدي 60 ثانية', const Padding(padding: EdgeInsets.all(30), child: Text('تحتاج 4 بطاقات على الأقل.', textAlign: TextAlign.center)));
    }
    if (!running && !over) {
      return uiPage(
          'تحدي 60 ثانية',
          Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const SizedBox(height: 30),
            const Text('⏱️', textAlign: TextAlign.center, style: TextStyle(fontSize: 70)),
            const SizedBox(height: 12),
            const Text('أجب عن أكبر عدد من الأسئلة خلال 60 ثانية.\nكل خطأ يخصم 3 ثوانٍ!',
                textAlign: TextAlign.center, style: TextStyle(height: 1.8, color: kSub)),
            const SizedBox(height: 16),
            Text('أفضل نتيجة: $best', textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 24),
            uiBtn('ابدأ التحدي', start),
          ]));
    }
    if (over) {
      return uiPage(
          'النتيجة',
          Column(children: [
            const SizedBox(height: 30),
            Text('$score', style: const TextStyle(fontSize: 72, fontWeight: FontWeight.w900)),
            const Text('إجابة صحيحة', style: TextStyle(color: kSub)),
            const SizedBox(height: 10),
            if (newBest) const Text('🎉 رقم قياسي جديد!', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            Text('أفضل نتيجة: $best · أطول تتابع صحيح: $maxCombo', style: const TextStyle(color: kSub)),
            const SizedBox(height: 24),
            uiBtn('إعادة التحدي', start),
            const SizedBox(height: 10),
            uiBtn('إغلاق', () => Navigator.pop(context), c: Colors.white, fg: kInk),
          ]));
    }
    final c = cur!;
    return uiPage(
        'تحدي 60 ثانية',
        Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            Text('⏱️ $left', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const Spacer(),
            if (combo >= 3) Text('🔥 x$combo  ', style: const TextStyle(fontWeight: FontWeight.w800)),
            Text('النقاط: $score', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          ]),
          const SizedBox(height: 8),
          LinearProgressIndicator(value: left / 60, minHeight: 8, color: left <= 10 ? Colors.red : kPeri, borderRadius: BorderRadius.circular(8)),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 34),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28)),
            child: Text(rev ? c.t : c.w,
                textAlign: TextAlign.center,
                textDirection: rev ? TextDirection.rtl : TextDirection.ltr,
                style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w800)),
          ),
          const SizedBox(height: 16),
          for (final o in opts)
            Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: uiBtn(o, picked != null ? null : () => answer(o),
                    c: picked == null ? Colors.white : (o == ans() ? kMint : (o == picked ? Colors.red.shade200 : Colors.white)), fg: kInk)),
        ]));
  }
}

// ---------------- أكمل الجملة ----------------
class ClozePage extends StatefulWidget {
  final List<Flash> cards;
  const ClozePage({super.key, required this.cards});
  @override
  State<ClozePage> createState() => _ClozeState();
}

class _ClozeState extends State<ClozePage> {
  final r = Random();
  late List<Flash> qs;
  List<String> opts = [];
  int i = 0, score = 0;
  String? picked;

  @override
  void initState() {
    super.initState();
    deal();
  }

  void deal() {
    final valid = widget.cards.where((c) => c.w.trim().length >= 2 && c.e.toLowerCase().contains(c.w.toLowerCase())).toList()..shuffle(r);
    qs = valid.take(10).toList();
    i = 0;
    score = 0;
    mk();
  }

  void mk() {
    if (i >= qs.length) return;
    final c = qs[i];
    final others = widget.cards.where((x) => x.w != c.w).map((x) => x.w).toSet().toList()..shuffle(r);
    opts = [c.w, ...others.take(3)]..shuffle(r);
    picked = null;
  }

  @override
  Widget build(BuildContext context) {
    if (widget.cards.length < 4) {
      return uiPage('أكمل الجملة', const Padding(padding: EdgeInsets.all(30), child: Text('تحتاج 4 بطاقات على الأقل.', textAlign: TextAlign.center)));
    }
    if (qs.isEmpty) {
      return uiPage(
          'أكمل الجملة',
          const Padding(
              padding: EdgeInsets.all(30),
              child: Text('لا توجد بطاقات فيها مثال يحتوي الكلمة.\nأضف أمثلة لبطاقاتك (زر «مثال ✨») ثم عُد.',
                  textAlign: TextAlign.center, style: TextStyle(height: 1.8, color: kSub))));
    }
    if (i >= qs.length) {
      return uiPage(
          'النتيجة',
          Column(children: [
            const SizedBox(height: 40),
            Text('$score / ${qs.length}', style: const TextStyle(fontSize: 56, fontWeight: FontWeight.w900)),
            const SizedBox(height: 24),
            uiBtn('إعادة', () => setState(deal)),
            const SizedBox(height: 10),
            uiBtn('إغلاق', () => Navigator.pop(context), c: Colors.white, fg: kInk),
          ]));
    }
    final c = qs[i];
    final blank = c.e.replaceAll(RegExp(RegExp.escape(c.w), caseSensitive: false), '_____');
    return uiPage(
        'جملة ${i + 1}/${qs.length}',
        Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          LinearProgressIndicator(value: (i + 1) / qs.length, color: kPeri, minHeight: 8, borderRadius: BorderRadius.circular(8)),
          const SizedBox(height: 22),
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28)),
            child: Column(children: [
              Text(blank, textAlign: TextAlign.center, textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700, height: 1.5)),
              const SizedBox(height: 10),
              Text('تلميح: ${c.t}', style: const TextStyle(color: kSub)),
            ]),
          ),
          const SizedBox(height: 16),
          for (final o in opts)
            Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: uiBtn(o, picked != null ? null : () => setState(() { picked = o; if (o == c.w) score++; }),
                    c: picked == null ? Colors.white : (o == c.w ? kMint : (o == picked ? Colors.red.shade200 : Colors.white)), fg: kInk)),
          if (picked != null)
            uiBtn(i == qs.length - 1 ? 'عرض النتيجة' : 'التالي', () => setState(() { i++; mk(); })),
        ]));
  }
}
