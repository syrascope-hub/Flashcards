class Flash {
  String id, w, t, e, d, img, x;
  bool k, f;
  int due, rep, iv, mt, lp;
  double ef;
  Flash(this.id, this.w, this.t,
      {this.e = '',
      this.k = false,
      this.f = false,
      this.d = 'عام',
      this.img = '',
      this.due = 0,
      this.rep = 0,
      this.iv = 0,
      this.ef = 2.5,
      this.x = '',
      this.mt = 0,
      this.lp = 0});

  /// x = تعريف/ملاحظات، mt = وقت آخر تعديل (للمزامنة)، lp = عدد مرات النسيان
  Map<String, dynamic> toJson() => {
        'id': id, 'w': w, 't': t, 'e': e, 'k': k, 'f': f, 'd': d, 'img': img,
        'due': due, 'rep': rep, 'iv': iv, 'ef': ef, 'x': x, 'mt': mt, 'lp': lp
      };

  factory Flash.fromJson(Map<String, dynamic> j) => Flash(j['id'].toString(), j['w'], j['t'],
      e: j['e'] ?? '',
      k: j['k'] ?? false,
      f: j['f'] ?? false,
      d: j['d'] ?? 'عام',
      img: j['img'] ?? '',
      due: ((j['due'] ?? 0) as num).toInt(),
      rep: ((j['rep'] ?? 0) as num).toInt(),
      iv: ((j['iv'] ?? 0) as num).toInt(),
      ef: ((j['ef'] ?? 2.5) as num).toDouble(),
      x: j['x'] ?? '',
      mt: ((j['mt'] ?? 0) as num).toInt(),
      lp: ((j['lp'] ?? 0) as num).toInt());

  bool get isDue => due <= DateTime.now().millisecondsSinceEpoch;

  /// كلمة صعبة: نُسيت مرتين أو أكثر، أو سهولتها منخفضة
  bool get isHard => lp >= 2 || ef < 1.9;

  /// 0 = صعبة، 1 = جيدة، 2 = سهلة (خوارزمية SM-2 مبسطة)
  void grade(int g) {
    final q = [2, 4, 5][g];
    final now = DateTime.now().millisecondsSinceEpoch;
    if (q < 3) {
      rep = 0;
      iv = 0;
      lp++;
      due = now + 10 * 60 * 1000;
    } else {
      rep++;
      iv = rep == 1 ? 1 : (rep == 2 ? 3 : (iv * ef).round());
      due = now + iv * 86400000;
      if (g == 2 && lp > 0) lp--;
    }
    ef = (ef + 0.1 - (5 - q) * (0.08 + (5 - q) * 0.02)).clamp(1.3, 3.0).toDouble();
    k = rep >= 3;
  }
}
