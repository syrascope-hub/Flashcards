import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'ai.dart';
import 'models.dart';
import 'illustrations.dart';
import 'more.dart';
import 'gam.dart';

const _mint = Color(0xFF72E3A5), _peri = Color(0xFFB4BEFF), _bg = Color(0xFFF5F6FF);
const _ink = Color(0xFF0B0B0B), _sub = Color(0xFF5D5F73);

Widget _page(String t, Widget body) => Scaffold(
      appBar: AppBar(title: Text(t, style: const TextStyle(fontWeight: FontWeight.w800)), backgroundColor: _bg),
      body: SafeArea(child: SingleChildScrollView(padding: const EdgeInsets.all(18), child: body)),
    );

Widget _btn(String s, VoidCallback? f, {Color c = _ink, Color fg = Colors.white}) => SizedBox(
      width: double.infinity,
      child: FilledButton(
        onPressed: f,
        style: FilledButton.styleFrom(
            backgroundColor: c,
            foregroundColor: fg,
            disabledBackgroundColor: c,
            disabledForegroundColor: fg,
            padding: const EdgeInsets.symmetric(vertical: 15),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
        child: Text(s, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
      ),
    );

// ---------------- اختبار اختيار من متعدد ----------------
class QuizPage extends StatefulWidget {
  final List<Flash> cards;
  const QuizPage({super.key, required this.cards});
  @override
  State<QuizPage> createState() => _QuizState();
}

class _QuizState extends State<QuizPage> {
  final r = Random();
  late List<Flash> qs;
  List<String> opts = [];
  int i = 0, score = 0;
  String? picked;

  @override
  void initState() {
    super.initState();
    qs = ([...widget.cards]..shuffle(r)).take(10).toList();
    mk();
  }

  void mk() {
    if (i >= qs.length) return;
    final c = qs[i];
    final others = widget.cards.where((x) => x.t != c.t).map((x) => x.t).toSet().toList()..shuffle(r);
    opts = [c.t, ...others.take(3)]..shuffle(r);
    picked = null;
  }

  @override
  Widget build(BuildContext context) {
    if (widget.cards.length < 4) {
      return _page('اختبار', const Padding(
          padding: EdgeInsets.all(30),
          child: Text('تحتاج 4 بطاقات على الأقل لبدء الاختبار.', textAlign: TextAlign.center)));
    }
    if (i >= qs.length) {
      return _page('النتيجة', Column(children: [
        const SizedBox(height: 40),
        Text('$score / ${qs.length}', style: const TextStyle(fontSize: 56, fontWeight: FontWeight.w900)),
        const SizedBox(height: 24),
        _btn('إعادة الاختبار', () => setState(() {
              qs.shuffle(r);
              i = 0;
              score = 0;
              mk();
            })),
        const SizedBox(height: 10),
        _btn('إغلاق', () => Navigator.pop(context), c: Colors.white, fg: _ink),
      ]));
    }
    final c = qs[i];
    return _page('سؤال ${i + 1}/${qs.length}', Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      LinearProgressIndicator(value: (i + 1) / qs.length, color: _peri, minHeight: 8,
          borderRadius: BorderRadius.circular(8)),
      const SizedBox(height: 24),
      Container(
        padding: const EdgeInsets.symmetric(vertical: 36),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28)),
        child: Text(c.w, textAlign: TextAlign.center, textDirection: TextDirection.ltr,
            style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800)),
      ),
      const SizedBox(height: 18),
      for (final o in opts)
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: _btn(
            o,
            picked != null
                ? null
                : () => setState(() {
                      picked = o;
                      if (o == c.t) score++;
                    }),
            c: picked == null ? Colors.white : (o == c.t ? _mint : (o == picked ? Colors.red.shade200 : Colors.white)),
            fg: _ink,
          ),
        ),
      if (picked != null) _btn(i == qs.length - 1 ? 'عرض النتيجة' : 'التالي', () => setState(() {
            i++;
            mk();
          })),
    ]));
  }
}

// ---------------- الإحصائيات ----------------
class StatsPage extends StatelessWidget {
  final List<Flash> cards;
  const StatsPage({super.key, required this.cards});
  @override
  Widget build(BuildContext context) {
    final decks = cards.map((c) => c.d).toSet().toList();
    final known = cards.where((c) => c.k).length;
    final due = cards.where((c) => c.isDue).length;
    Widget row(String l, int v) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
            child: Row(children: [
              Expanded(child: Text(l, style: const TextStyle(fontWeight: FontWeight.w700))),
              Text('$v', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            ])));
    return _page('الإحصائيات', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      if (cards.isEmpty) const EmptyState(kind: Ill.chart, title: 'لا توجد بيانات بعد', sub: 'ابدأ المراجعة لتظهر إحصائياتك هنا'),
      row('إجمالي البطاقات', cards.length),
      row('محفوظة', known),
      row('مستحقة الآن', due),
      const Text('نشاط آخر 7 أيام', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
      const SizedBox(height: 8),
      FutureBuilder<SharedPreferences>(
          future: SharedPreferences.getInstance(),
          builder: (_, sn) {
            if (!sn.hasData) return const SizedBox(height: 120);
            final h = Map<String, dynamic>.from(jsonDecode(sn.data!.getString('hist') ?? '{}'));
            final days = [for (var b = 6; b >= 0; b--) (h[dayKey(b)] ?? 0) as int];
            final mx = days.fold<int>(1, (a, b) => max(a, b));
            return SizedBox(
                height: 130,
                child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  for (final v in days)
                    Expanded(
                        child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                      Text('$v', style: const TextStyle(fontSize: 12, color: _sub)),
                      Container(
                          height: 6 + 80.0 * v / mx,
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          decoration: BoxDecoration(color: _peri, borderRadius: BorderRadius.circular(8))),
                    ])),
                ]));
          }),
      const SizedBox(height: 18),
      const Text('نشاطك في آخر 12 أسبوعًا', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
      const SizedBox(height: 10),
      const HeatmapLoader(),
      const SizedBox(height: 16),
      const MotivCard(),
      const SizedBox(height: 10),
      const Text('التقدم حسب المجموعة', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
      const SizedBox(height: 10),
      for (final d in decks) ...[
        Builder(builder: (_) {
          final all = cards.where((c) => c.d == d).toList();
          final k = all.where((c) => c.k).length;
          return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('$d  ($k/${all.length})', style: const TextStyle(color: _sub)),
            const SizedBox(height: 4),
            LinearProgressIndicator(value: all.isEmpty ? 0 : k / all.length, color: _mint,
                backgroundColor: Colors.white, minHeight: 10, borderRadius: BorderRadius.circular(8)),
            const SizedBox(height: 14),
          ]);
        })
      ],
    ]));
  }
}

// ---------------- اختبار الكتابة ----------------
class TypePage extends StatefulWidget {
  final List<Flash> cards;
  const TypePage({super.key, required this.cards});
  @override
  State<TypePage> createState() => _TypeState();
}

class _TypeState extends State<TypePage> {
  late List<Flash> qs;
  final c = TextEditingController();
  int i = 0, score = 0;
  bool? ok;

  @override
  void initState() {
    super.initState();
    qs = ([...widget.cards]..shuffle()).take(10).toList();
  }

  @override
  Widget build(BuildContext context) {
    if (qs.isEmpty) return _page('اختبار الكتابة', const Center(child: Text('أضف بطاقات أولًا.')));
    if (i >= qs.length) {
      return _page('النتيجة', Column(children: [
        const SizedBox(height: 40),
        Text('$score / ${qs.length}', style: const TextStyle(fontSize: 56, fontWeight: FontWeight.w900)),
        const SizedBox(height: 24),
        _btn('إغلاق', () => Navigator.pop(context)),
      ]));
    }
    final q = qs[i];
    return _page('سؤال ${i + 1}/${qs.length}', Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Container(
        padding: const EdgeInsets.symmetric(vertical: 36),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28)),
        child: Text(q.t, textAlign: TextAlign.center, style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800)),
      ),
      const SizedBox(height: 16),
      TextField(
        controller: c,
        enabled: ok == null,
        autofocus: true,
        textDirection: TextDirection.ltr,
        decoration: InputDecoration(
            hintText: 'اكتب الكلمة بالإنجليزية',
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16))),
        onSubmitted: (_) => ok == null ? check() : null,
      ),
      const SizedBox(height: 12),
      if (ok != null)
        Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Text(ok! ? 'صحيح ✓' : 'الإجابة: ${q.w}',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: ok! ? const Color(0xFF0A7A45) : Colors.red.shade700))),
      _btn(ok == null ? 'تحقق' : 'التالي', ok == null ? check : () => setState(() {
            i++;
            ok = null;
            c.clear();
          })),
    ]));
  }

  void check() => setState(() {
        ok = c.text.trim().toLowerCase() == qs[i].w.toLowerCase();
        if (ok!) score++;
      });
}

// ---------------- لعبة المطابقة ----------------
class MatchPage extends StatefulWidget {
  final List<Flash> cards;
  const MatchPage({super.key, required this.cards});
  @override
  State<MatchPage> createState() => _MatchState();
}

class _MatchState extends State<MatchPage> {
  late List<Flash> pick, left, right;
  String? sel;
  final done = <String>{};
  int tries = 0;

  @override
  void initState() {
    super.initState();
    pick = ([...widget.cards]..shuffle()).take(6).toList();
    left = [...pick]..shuffle();
    right = [...pick]..shuffle();
  }

  Widget cell(Flash f, bool isLeft) {
    final d = done.contains(f.id);
    return Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: _btn(isLeft ? f.w : f.t, d ? null : () => setState(() {
              if (isLeft) {
                sel = f.id;
              } else if (sel != null) {
                tries++;
                if (sel == f.id) done.add(f.id);
                sel = null;
              }
            }), c: d ? _mint : (isLeft && sel == f.id ? _peri : Colors.white), fg: _ink));
  }

  @override
  Widget build(BuildContext context) {
    if (widget.cards.length < 3) return _page('المطابقة', const Center(child: Text('تحتاج 3 بطاقات على الأقل.')));
    if (done.length == pick.length) {
      return _page('أحسنت 🎉', Column(children: [
        const SizedBox(height: 40),
        Text('انتهيت بـ $tries محاولة', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
        const SizedBox(height: 24),
        _btn('إغلاق', () => Navigator.pop(context)),
      ]));
    }
    return _page('طابق الكلمة بترجمتها', Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Expanded(child: Column(children: [for (final f in left) cell(f, true)])),
      const SizedBox(width: 10),
      Expanded(child: Column(children: [for (final f in right) cell(f, false)])),
    ]));
  }
}

// ---------------- اختبار الاستماع ----------------
class ListenPage extends StatefulWidget {
  final List<Flash> cards;
  const ListenPage({super.key, required this.cards});
  @override
  State<ListenPage> createState() => _ListenState();
}

class _ListenState extends State<ListenPage> {
  final tts = FlutterTts();
  final r = Random();
  late List<Flash> qs;
  List<String> opts = [];
  int i = 0, score = 0;
  String? picked;

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      tts.setLanguage(p.getString('lang') ?? 'en-US');
      tts.setSpeechRate(p.getDouble('rate') ?? .5);
    });
    qs = ([...widget.cards]..shuffle(r)).take(10).toList();
    mk();
  }

  void mk() {
    if (i >= qs.length) return;
    final c = qs[i];
    final o = widget.cards.where((x) => x.w != c.w).map((x) => x.w).toSet().toList()..shuffle(r);
    opts = [c.w, ...o.take(3)]..shuffle(r);
    picked = null;
    WidgetsBinding.instance.addPostFrameCallback((_) => tts.speak(c.w));
  }

  @override
  Widget build(BuildContext context) {
    if (widget.cards.length < 4) return _page('الاستماع', const Center(child: Text('تحتاج 4 بطاقات على الأقل.')));
    if (i >= qs.length) {
      return _page('النتيجة', Column(children: [
        const SizedBox(height: 40),
        Text('$score / ${qs.length}', style: const TextStyle(fontSize: 56, fontWeight: FontWeight.w900)),
        const SizedBox(height: 24),
        _btn('إغلاق', () => Navigator.pop(context)),
      ]));
    }
    final c = qs[i];
    return _page('سؤال ${i + 1}/${qs.length}', Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Center(
          child: IconButton.filled(
              iconSize: 48,
              style: IconButton.styleFrom(backgroundColor: _ink, padding: const EdgeInsets.all(28)),
              onPressed: () => tts.speak(c.w),
              icon: const Icon(Icons.volume_up))),
      const SizedBox(height: 8),
      const Text('اضغط للاستماع ثم اختر الكلمة الصحيحة', textAlign: TextAlign.center, style: TextStyle(color: _sub)),
      const SizedBox(height: 18),
      for (final o in opts)
        Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: _btn(o, picked != null ? null : () => setState(() {
                  picked = o;
                  if (o == c.w) score++;
                }), c: picked == null ? Colors.white : (o == c.w ? _mint : (o == picked ? Colors.red.shade200 : Colors.white)), fg: _ink)),
      if (picked != null) _btn('التالي', () => setState(() { i++; mk(); })),
    ]));
  }
}
