import 'package:flutter/material.dart';

// عناصر واجهة مشتركة للشاشات الجديدة
const kInk = Color(0xFF0B0B0B);
const kSub = Color(0xFF5D5F73);
const kBg = Color(0xFFF5F6FF);
const kMint = Color(0xFF72E3A5);
const kPeri = Color(0xFFB4BEFF);
const kLilac = Color(0xFFBFA0EA);
const kPink = Color(0xFFFFD3E0);

Widget uiPage(String t, Widget body) => Scaffold(
      appBar: AppBar(title: Text(t, style: const TextStyle(fontWeight: FontWeight.w800)), backgroundColor: kBg),
      body: SafeArea(child: SingleChildScrollView(padding: const EdgeInsets.all(18), child: body)),
    );

Widget uiBtn(String s, VoidCallback? f, {Color c = kInk, Color fg = Colors.white}) => SizedBox(
      width: double.infinity,
      child: FilledButton(
        onPressed: f,
        style: FilledButton.styleFrom(
            backgroundColor: c,
            foregroundColor: fg,
            disabledBackgroundColor: c,
            disabledForegroundColor: fg,
            padding: const EdgeInsets.symmetric(vertical: 15),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
        child: Text(s, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
      ),
    );

InputDecoration uiDeco(String h) => InputDecoration(
      hintText: h,
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.all(14),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
    );

Widget uiBox(Widget child, {Color c = Colors.white}) => Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(20)),
      child: child,
    );

Widget uiHead(String s) => Padding(
    padding: const EdgeInsets.only(top: 14, bottom: 8),
    child: Text(s, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)));
