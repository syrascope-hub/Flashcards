import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'ai.dart';
import 'models.dart';
import 'ui.dart';

/// عدد الأيام بين آخر يوم نشاط (بصيغة y-m-d) واليوم. 99 إذا لا يوجد.
int gapDays(String? last) {
  if (last == null) return 99;
  final p = last.split('-');
  if (p.length != 3) return 99;
  try {
    final a = DateTime.utc(int.parse(p[0]), int.parse(p[1]), int.parse(p[2]));
    final n = DateTime.now();
    return DateTime.utc(n.year, n.month, n.day).difference(a).inDays;
  } catch (_) {
    return 99;
  }
}

class GStats {
  final int total, best, known, cards, goalDays, activeDays;
  const GStats(this.total, this.best, this.known, this.cards, this.goalDays, this.activeDays);
}

/// شارة إنجاز
class Achv {
  final String id, emoji, title, desc;
  final bool Function(GStats) ok;
  Achv(this.id, this.emoji, this.title, this.desc, this.ok);
}

final List<Achv> kAchv = [
  Achv('first', '🌱', 'البداية', 'أنجز أول مراجعة', (s) => s.total >= 1),
  Achv('r100', '📘', '100 مراجعة', 'راجع 100 بطاقة', (s) => s.total >= 100),
  Achv('r500', '📚', '500 مراجعة', 'راجع 500 بطاقة', (s) => s.total >= 500),
  Achv('r1000', '🏆', '1000 مراجعة', 'راجع 1000 بطاقة', (s) => s.total >= 1000),
  Achv('s3', '🔥', 'ثلاثة أيام', 'سلسلة 3 أيام متتالية', (s) => s.best >= 3),
  Achv('s7', '⚡', 'أسبوع كامل', 'سلسلة 7 أيام متتالية', (s) => s.best >= 7),
  Achv('s30', '👑', 'شهر متواصل', 'سلسلة 30 يومًا متتالية', (s) => s.best >= 30),
  Achv('k10', '🧠', '10 كلمات', 'احفظ 10 كلمات', (s) => s.known >= 10),
  Achv('k50', '🎓', '50 كلمة', 'احفظ 50 كلمة', (s) => s.known >= 50),
  Achv('k200', '🌟', '200 كلمة', 'احفظ 200 كلمة', (s) => s.known >= 200),
  Achv('c25', '🗂️', '25 بطاقة', 'أضف 25 بطاقة', (s) => s.cards >= 25),
  Achv('c100', '🏛️', '100 بطاقة', 'أضف 100 بطاقة', (s) => s.cards >= 100),
  Achv('g5', '🎯', 'هدف 5 مرات', 'حقق هدفك اليومي 5 مرات', (s) => s.goalDays >= 5),
  Achv('g20', '🚀', 'هدف 20 مرة', 'حقق هدفك اليومي 20 مرة', (s) => s.goalDays >= 20),
  Achv('d14', '📅', 'نشاط 14 يومًا', 'تدرّب في 14 يومًا مختلفًا', (s) => s.activeDays >= 14),
];

class GamResult {
  final int xp, level, freeze;
  final bool levelUp;
  final List<Achv> newBadges;
  GamResult(this.xp, this.level, this.freeze, this.levelUp, this.newBadges);
}

class Gam {
  static int levelOf(int xp) => sqrt(xp / 50).floor() + 1;
  static int xpFor(int level) => 50 * (level - 1) * (level - 1);

  static Future<GStats> stats(SharedPreferences p, List<Flash> cards, int goal) async {
    final h = Map<String, dynamic>.from(jsonDecode(p.getString('hist') ?? '{}'));
    var sum = 0, gd = 0;
    for (final v in h.values) {
      final n = (v as num).toInt();
      sum += n;
      if (n >= goal) gd++;
    }
    return GStats(p.getInt('total') ?? sum, max(p.getInt('best') ?? 0, p.getInt('streak') ?? 0),
        cards.where((c) => c.k).length, cards.length, gd, h.length);
  }

  /// تُستدعى بعد كل مراجعة: نقاط الخبرة، المستوى، أفضل سلسلة، التجميد، والشارات الجديدة.
  static Future<GamResult> record({required List<Flash> cards, required int goal, required int cnt, required int streak}) async {
    final p = await SharedPreferences.getInstance();
    var xp = p.getInt('xp') ?? 0;
    final oldLv = levelOf(xp);
    xp += 10 + (cnt == goal ? 50 : 0);
    await p.setInt('xp', xp);

    // إجمالي المراجعات (للمستخدمين القدامى نبدأ من مجموع السجل)
    final h = Map<String, dynamic>.from(jsonDecode(p.getString('hist') ?? '{}'));
    final histSum = h.values.fold<int>(0, (a, v) => a + (v as num).toInt());
    await p.setInt('total', p.containsKey('total') ? (p.getInt('total') ?? 0) + 1 : histSum);
    if (streak > (p.getInt('best') ?? 0)) await p.setInt('best', streak);

    // كل 7 أيام متتالية = تجميد سلسلة (حد أقصى 2)
    var fr = p.getInt('freeze') ?? 0;
    if (cnt == 1 && streak > 0 && streak % 7 == 0 && fr < 2) {
      fr++;
      await p.setInt('freeze', fr);
    }

    final st = await stats(p, cards, goal);
    final have = (p.getStringList('badges') ?? []).toSet();
    final fresh = kAchv.where((a) => !have.contains(a.id) && a.ok(st)).toList();
    if (fresh.isNotEmpty) await p.setStringList('badges', [...have, ...fresh.map((a) => a.id)]);
    final lv = levelOf(xp);
    return GamResult(xp, lv, fr, lv > oldLv, fresh);
  }
}

// ---------------- خريطة النشاط ----------------
class Heatmap extends StatelessWidget {
  final Map<String, dynamic> hist;
  final int goal;
  final int weeks;
  const Heatmap({super.key, required this.hist, required this.goal, this.weeks = 12});

  Color col(int v) {
    if (v <= 0) return const Color(0xFFE3E5F3);
    final r = v / (goal <= 0 ? 1 : goal);
    if (r < .5) return kMint.withOpacity(.4);
    if (r < 1) return kMint.withOpacity(.7);
    return const Color(0xFF2FBF71);
  }

  @override
  Widget build(BuildContext context) {
    final n = weeks * 7;
    return Directionality(
      textDirection: TextDirection.ltr,
      child: LayoutBuilder(builder: (_, c) {
        final cell = ((c.maxWidth - (weeks - 1) * 3) / weeks).floorToDouble();
        return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          for (var w = 0; w < weeks; w++)
            Column(children: [
              for (var d = 0; d < 7; d++)
                Builder(builder: (_) {
                  final k = w * 7 + d;
                  final back = n - 1 - k;
                  final v = back < 0 ? 0 : ((hist[dayKey(back)] ?? 0) as num).toInt();
                  return Container(
                      width: cell,
                      height: cell,
                      margin: const EdgeInsets.only(bottom: 3),
                      decoration: BoxDecoration(color: col(v), borderRadius: BorderRadius.circular(4)));
                }),
            ]),
        ]);
      }),
    );
  }
}

class HeatmapLoader extends StatelessWidget {
  const HeatmapLoader({super.key});
  @override
  Widget build(BuildContext context) => FutureBuilder<SharedPreferences>(
      future: SharedPreferences.getInstance(),
      builder: (_, sn) {
        if (!sn.hasData) return const SizedBox(height: 120);
        final p = sn.data!;
        final h = Map<String, dynamic>.from(jsonDecode(p.getString('hist') ?? '{}'));
        return Heatmap(hist: h, goal: p.getInt('goal') ?? 20);
      });
}

// ---------------- شاشة التقدّم: المستوى والشارات ----------------
class ProgressPage extends StatelessWidget {
  final List<Flash> cards;
  final int goal;
  const ProgressPage({super.key, required this.cards, required this.goal});

  @override
  Widget build(BuildContext context) => FutureBuilder<SharedPreferences>(
      future: SharedPreferences.getInstance(),
      builder: (ctx, sn) {
        if (!sn.hasData) return uiPage('إنجازاتك', const SizedBox(height: 200));
        final p = sn.data!;
        return FutureBuilder<GStats>(
            future: Gam.stats(p, cards, goal),
            builder: (_, gs) {
              if (!gs.hasData) return uiPage('إنجازاتك', const SizedBox(height: 200));
              final st = gs.data!;
              final xp = p.getInt('xp') ?? 0;
              final lv = Gam.levelOf(xp);
              final lo = Gam.xpFor(lv), hi = Gam.xpFor(lv + 1);
              final h = Map<String, dynamic>.from(jsonDecode(p.getString('hist') ?? '{}'));
              Widget mini(String big, String small) => Expanded(
                  child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
                      child: Column(children: [
                        Text(big, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 2),
                        Text(small, style: const TextStyle(color: kSub, fontSize: 12)),
                      ])));
              final got = kAchv.where((a) => a.ok(st)).length;
              return uiPage(
                  'إنجازاتك',
                  Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    uiBox(
                        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('المستوى $lv', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
                          const SizedBox(height: 10),
                          LinearProgressIndicator(
                              value: ((xp - lo) / (hi - lo)).clamp(0.0, 1.0).toDouble(),
                              minHeight: 12,
                              color: const Color(0xFF2FBF71),
                              backgroundColor: Colors.white,
                              borderRadius: BorderRadius.circular(8)),
                          const SizedBox(height: 8),
                          Text('$xp نقطة خبرة · يتبقى ${hi - xp} للمستوى التالي', style: const TextStyle(color: kInk)),
                        ]),
                        c: kLilac),
                    Row(children: [
                      mini('${p.getInt('streak') ?? 0}', 'سلسلة 🔥'),
                      mini('${st.best}', 'أفضل سلسلة'),
                      mini('${p.getInt('freeze') ?? 0}', 'تجميد ❄️'),
                    ]),
                    const SizedBox(height: 6),
                    const Text('كل 7 أيام متتالية تمنحك «تجميد سلسلة» ينقذها إذا فاتك يوم واحد.',
                        style: TextStyle(color: kSub, height: 1.6, fontSize: 13)),
                    uiHead('الشارات ($got/${kAchv.length})'),
                    GridView.count(
                        crossAxisCount: 3,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        mainAxisSpacing: 10,
                        crossAxisSpacing: 10,
                        childAspectRatio: .95,
                        children: [
                          for (final a in kAchv)
                            InkWell(
                                borderRadius: BorderRadius.circular(18),
                                onTap: () => showDialog(
                                    context: ctx,
                                    builder: (_) => AlertDialog(
                                        title: Text('${a.emoji} ${a.title}'),
                                        content: Text(a.desc + (a.ok(st) ? '\n\n✅ تم إنجازها' : '')))),
                                child: Opacity(
                                    opacity: a.ok(st) ? 1 : .4,
                                    child: Container(
                                        padding: const EdgeInsets.all(8),
                                        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
                                        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                                          Text(a.ok(st) ? a.emoji : '🔒', style: const TextStyle(fontSize: 30)),
                                          const SizedBox(height: 4),
                                          Text(a.title,
                                              textAlign: TextAlign.center,
                                              maxLines: 2,
                                              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                                        ])))),
                        ]),
                    uiHead('نشاطك في آخر 12 أسبوعًا'),
                    Heatmap(hist: h, goal: goal),
                  ]));
            });
      });
}
