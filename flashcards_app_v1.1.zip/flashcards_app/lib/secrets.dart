import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// تخزين آمن للمفاتيح (Keystore على أندرويد / Keychain على iOS)
class Secrets {
  static const _ss = FlutterSecureStorage(aOptions: AndroidOptions(encryptedSharedPreferences: true));

  static Future<String> get(String k) async {
    try {
      return (await _ss.read(key: k)) ?? '';
    } catch (_) {
      return '';
    }
  }

  static Future<void> set(String k, String v) async {
    try {
      if (v.isEmpty) {
        await _ss.delete(key: k);
      } else {
        await _ss.write(key: k, value: v);
      }
    } catch (_) {}
  }

  /// مفتاح Hugging Face. ينقل المفتاح القديم تلقائيًا من التخزين العادي إلى الآمن.
  static Future<String> hfToken() async {
    var t = await get('hf');
    if (t.isEmpty) {
      final p = await SharedPreferences.getInstance();
      final old = p.getString('hf') ?? '';
      if (old.isNotEmpty) {
        await set('hf', old);
        if (await get('hf') == old) await p.remove('hf');
        t = old;
      }
    }
    return t;
  }
}
