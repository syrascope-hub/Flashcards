import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

class DictInfo {
  String phonetic = '', pos = '', def = '', example = '';
  List<String> syn = [];

  /// نص جاهز لحقل التعريف/الملاحظات
  String note() {
    final b = StringBuffer();
    if (phonetic.isNotEmpty) b.writeln(phonetic);
    if (def.isNotEmpty) b.writeln(pos.isEmpty ? def : '($pos) $def');
    if (syn.isNotEmpty) b.write('≈ ${syn.join(', ')}');
    return b.toString().trim();
  }
}

/// قاموس إنجليزي مجاني (dictionaryapi.dev) بدون مفتاح. يُرجع null إذا لم توجد الكلمة.
Future<DictInfo?> dictLookup(String w) async {
  final r = await http
      .get(Uri.parse('https://api.dictionaryapi.dev/api/v2/entries/en/${Uri.encodeComponent(w.trim().toLowerCase())}'))
      .timeout(const Duration(seconds: 15));
  if (r.statusCode != 200) return null;
  final j = jsonDecode(utf8.decode(r.bodyBytes));
  if (j is! List || j.isEmpty) return null;
  final e = j.first as Map;
  final d = DictInfo();
  d.phonetic = (e['phonetic'] ?? '').toString();
  if (d.phonetic.isEmpty) {
    for (final p in (e['phonetics'] as List? ?? [])) {
      final t = ((p as Map)['text'] ?? '').toString();
      if (t.isNotEmpty) {
        d.phonetic = t;
        break;
      }
    }
  }
  final syn = <String>{};
  for (final m in (e['meanings'] as List? ?? [])) {
    final mm = m as Map;
    if (d.def.isEmpty) d.pos = (mm['partOfSpeech'] ?? '').toString();
    for (final s in (mm['synonyms'] as List? ?? [])) {
      syn.add(s.toString());
    }
    for (final df in (mm['definitions'] as List? ?? [])) {
      final dm = df as Map;
      if (d.def.isEmpty) d.def = (dm['definition'] ?? '').toString();
      if (d.example.isEmpty) d.example = (dm['example'] ?? '').toString();
      for (final s in (dm['synonyms'] as List? ?? [])) {
        syn.add(s.toString());
      }
    }
  }
  d.syn = syn.take(5).toList();
  return d;
}

/// صورة مصغّرة من ويكيبيديا للكلمة (تعمل مع الأسماء المعروفة غالبًا). تُحفظ في مجلد التطبيق.
Future<String?> fetchWikiImage(String w, {String lang = 'en'}) async {
  final r = await http.get(
      Uri.parse('https://$lang.wikipedia.org/api/rest_v1/page/summary/${Uri.encodeComponent(w.trim())}'),
      headers: {'User-Agent': 'FlashcardsApp/1.1'}).timeout(const Duration(seconds: 15));
  if (r.statusCode != 200) return null;
  final j = jsonDecode(utf8.decode(r.bodyBytes));
  if (j is! Map || j['type'] == 'disambiguation') return null;
  final th = j['thumbnail'];
  final src = th is Map ? th['source']?.toString() : null;
  if (src == null || src.isEmpty) return null;
  final img = await http.get(Uri.parse(src), headers: {'User-Agent': 'FlashcardsApp/1.1'}).timeout(const Duration(seconds: 20));
  if (img.statusCode != 200) return null;
  final dir = await getApplicationDocumentsDirectory();
  final f = File('${dir.path}/${DateTime.now().microsecondsSinceEpoch}.jpg');
  await f.writeAsBytes(img.bodyBytes);
  return f.path;
}
