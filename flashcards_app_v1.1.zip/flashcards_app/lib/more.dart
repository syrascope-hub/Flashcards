import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'illustrations.dart';
import 'notif.dart';

const _ink = Color(0xFF0B0B0B), _sub = Color(0xFF5D5F73), _bg = Color(0xFFF5F6FF);
const _peri = Color(0xFFB4BEFF), _mint = Color(0xFF72E3A5), _lilac = Color(0xFFBFA0EA);

Widget _scaffold(String t, Widget body, {Widget? fab}) => Scaffold(
      appBar: AppBar(title: Text(t, style: const TextStyle(fontWeight: FontWeight.w800)), backgroundColor: _bg),
      floatingActionButton: fab,
      body: SafeArea(child: body),
    );

InputDecoration _deco(String h) => InputDecoration(
      hintText: h,
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.all(14),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
    );

// ---------------- عناصر مشتركة ----------------
class EmptyState extends StatelessWidget {
  final Ill kind;
  final String title, sub;
  const EmptyState({super.key, required this.kind, required this.title, required this.sub});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 24),
        child: Center(
            child: Column(children: [
          Illo(kind, size: 130),
          const SizedBox(height: 8),
          Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Text(sub, textAlign: TextAlign.center, style: const TextStyle(color: _sub, height: 1.6)),
        ])),
      );
}

class MotivCard extends StatelessWidget {
  const MotivCard({super.key});
  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(vertical: 10),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: const Color(0xFFE8DEFF), borderRadius: BorderRadius.circular(28)),
        child: const Row(children: [
          Icon(Icons.auto_awesome, color: Color(0xFF8B7BE8)),
          SizedBox(width: 12),
          Expanded(
              child: Text('خطوة صغيرة كل يوم..\nتصنع فرقًا كبيرًا',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, height: 1.6))),
        ]),
      );
}

class HomeGridCard extends StatelessWidget {
  final String label;
  final Ill kind;
  final VoidCallback onTap;
  const HomeGridCard({super.key, required this.label, required this.kind, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(
        borderRadius: BorderRadius.circular(26),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(26),
              boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 10, offset: Offset(0, 4))]),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, maxLines: 2, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, height: 1.3)),
            Expanded(child: Center(child: Illo(kind, size: 82))),
          ]),
        ),
      );
}

Future<void> showCelebration(BuildContext context, {required int streak, required int cnt, required int goal}) {
  final done = cnt >= goal;
  return showDialog(
      context: context,
      builder: (_) => AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
            content: Column(mainAxisSize: MainAxisSize.min, children: [
              const Illo(Ill.trophy, size: 130),
              const Text('أنجز واستمر', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              Text(
                  done
                      ? 'أحسنت! وصلت إلى هدفك اليومي ($goal بطاقة).\nسلسلتك الحالية: $streak يوم.'
                      : 'راجعت $cnt من $goal بطاقة اليوم.\nسلسلتك الحالية: $streak يوم.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(height: 1.7, color: _sub)),
            ]),
            actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('متابعة'))],
          ));
}

class ReminderBanner extends StatelessWidget {
  final int cnt, goal;
  const ReminderBanner({super.key, required this.cnt, required this.goal});
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: const Color(0xFFFFE1E6), borderRadius: BorderRadius.circular(22)),
        child: Row(children: [
          const Illo(Ill.bell, size: 54),
          const SizedBox(width: 10),
          Expanded(
              child: Text('حان وقت المراجعة! أنجزت $cnt من $goal اليوم.',
                  style: const TextStyle(fontWeight: FontWeight.w800, height: 1.5))),
        ]),
      );
}

// ---------------- شاشة الترحيب ----------------
class OnboardingPage extends StatefulWidget {
  final VoidCallback onDone;
  const OnboardingPage({super.key, required this.onDone});
  @override
  State<OnboardingPage> createState() => _OnbState();
}

class _OnbState extends State<OnboardingPage> {
  final pc = PageController();
  int i = 0;
  static const kinds = [Ill.target, Ill.brain, Ill.student];
  static const titles = ['حقق أهدافك', 'تعلّم بذكاء', 'ابدأ دراستك الآن'];
  static const subs = [
    'حدّد هدفًا يوميًا وتابع سلسلتك يومًا بعد يوم',
    'تكرار متباعد يذكّرك بالكلمة في الوقت المناسب',
    'أضف بطاقاتك الأولى وانطلق',
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: _bg,
        body: SafeArea(
          child: Column(children: [
            Align(
                alignment: AlignmentDirectional.centerEnd,
                child: TextButton(onPressed: widget.onDone, child: const Text('تخطي'))),
            Expanded(
              child: PageView.builder(
                controller: pc,
                itemCount: 3,
                onPageChanged: (v) => setState(() => i = v),
                itemBuilder: (_, n) => Padding(
                  padding: const EdgeInsets.all(28),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Illo(kinds[n], size: 230),
                    const SizedBox(height: 24),
                    Text(titles[n], style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 10),
                    Text(subs[n], textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, color: _sub, height: 1.7)),
                  ]),
                ),
              ),
            ),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              for (var n = 0; n < 3; n++)
                AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    margin: const EdgeInsets.all(4),
                    width: i == n ? 24 : 8,
                    height: 8,
                    decoration: BoxDecoration(color: i == n ? _ink : _peri, borderRadius: BorderRadius.circular(8))),
            ]),
            Padding(
              padding: const EdgeInsets.all(22),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () {
                    if (i == 2) {
                      widget.onDone();
                    } else {
                      pc.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
                    }
                  },
                  style: FilledButton.styleFrom(
                      backgroundColor: _ink,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                  child: Text(i == 2 ? 'ابدأ' : 'التالي', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                ),
              ),
            ),
          ]),
        ),
      );
}

// ---------------- إدارة المهام ----------------
class TasksPage extends StatefulWidget {
  const TasksPage({super.key});
  @override
  State<TasksPage> createState() => _TasksState();
}

class _TasksState extends State<TasksPage> {
  List<Map<String, dynamic>> items = [];
  final c = TextEditingController();

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      final s = p.getString('tasks');
      if (s != null && mounted) {
        setState(() => items = (jsonDecode(s) as List).map((e) => Map<String, dynamic>.from(e)).toList());
      }
    });
  }

  Future<void> save() async => (await SharedPreferences.getInstance()).setString('tasks', jsonEncode(items));

  void add() {
    final t = c.text.trim();
    if (t.isEmpty) return;
    setState(() => items.insert(0, {'id': DateTime.now().microsecondsSinceEpoch.toString(), 't': t, 'd': false}));
    c.clear();
    save();
  }

  @override
  Widget build(BuildContext context) {
    final done = items.where((e) => e['d'] == true).length;
    return _scaffold(
        'إدارة المهام',
        Column(children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
                controller: c,
                onSubmitted: (_) => add(),
                decoration: _deco('مهمة جديدة').copyWith(suffixIcon: IconButton(icon: const Icon(Icons.add_circle, color: _ink), onPressed: add))),
          ),
          if (items.isNotEmpty)
            Padding(
                padding: const EdgeInsets.symmetric(horizontal: 18),
                child: Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: Text('أنجزت $done من ${items.length}', style: const TextStyle(color: _sub, fontWeight: FontWeight.w700)))),
          Expanded(
              child: items.isEmpty
                  ? const SingleChildScrollView(child: EmptyState(kind: Ill.tasks, title: 'لا توجد مهام', sub: 'اكتب مهمتك الأولى بالأعلى'))
                  : ListView(padding: const EdgeInsets.all(12), children: [
                      for (final it in items)
                        Dismissible(
                          key: ValueKey(it['id']),
                          background: Container(color: const Color(0xFFFFD3E0)),
                          onDismissed: (_) {
                            setState(() => items.remove(it));
                            save();
                          },
                          child: Card(
                            elevation: 0,
                            child: CheckboxListTile(
                              value: it['d'] == true,
                              activeColor: _ink,
                              title: Text(it['t'],
                                  style: TextStyle(
                                      fontWeight: FontWeight.w700,
                                      decoration: it['d'] == true ? TextDecoration.lineThrough : null)),
                              onChanged: (v) {
                                setState(() => it['d'] = v ?? false);
                                save();
                              },
                            ),
                          ),
                        ),
                    ])),
        ]));
  }
}

// ---------------- ملاحظاتك ----------------
class NotesPage extends StatefulWidget {
  const NotesPage({super.key});
  @override
  State<NotesPage> createState() => _NotesState();
}

class _NotesState extends State<NotesPage> {
  List<String> items = [];

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      if (mounted) setState(() => items = p.getStringList('notes') ?? []);
    });
  }

  Future<void> save() async => (await SharedPreferences.getInstance()).setStringList('notes', items);

  Future<void> add() async {
    final c = TextEditingController();
    final t = await showDialog<String>(
        context: context,
        builder: (_) => AlertDialog(
              title: const Text('ملاحظة جديدة'),
              content: TextField(controller: c, autofocus: true, minLines: 3, maxLines: 6, decoration: _deco('اكتب ملاحظتك')),
              actions: [TextButton(onPressed: () => Navigator.pop(context, c.text.trim()), child: const Text('حفظ'))],
            ));
    if (t != null && t.isNotEmpty) {
      setState(() => items.insert(0, t));
      save();
    }
  }

  @override
  Widget build(BuildContext context) => _scaffold(
      'ملاحظاتك',
      items.isEmpty
          ? const SingleChildScrollView(child: EmptyState(kind: Ill.notes, title: 'لا توجد ملاحظات', sub: 'اضغط + لتدوين أول ملاحظة'))
          : ListView(padding: const EdgeInsets.all(16), children: [
              for (var i = 0; i < items.length; i++)
                Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
                  child: Row(children: [
                    Expanded(child: Text(items[i], style: const TextStyle(height: 1.6, fontWeight: FontWeight.w600))),
                    IconButton(
                        icon: const Icon(Icons.delete_outline, color: _sub),
                        onPressed: () {
                          setState(() => items.removeAt(i));
                          save();
                        }),
                  ]),
                ),
            ]),
      fab: FloatingActionButton(onPressed: add, backgroundColor: _ink, foregroundColor: Colors.white, child: const Icon(Icons.add)));
}

// ---------------- خطط لوقتك ----------------
class PlannerPage extends StatefulWidget {
  const PlannerPage({super.key});
  @override
  State<PlannerPage> createState() => _PlannerState();
}

class _PlannerState extends State<PlannerPage> {
  static const days = ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'];
  Map<String, List<String>> plan = {};
  int sel = (DateTime.now().weekday + 1) % 7;
  final c = TextEditingController();

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      final s = p.getString('plan');
      if (s != null && mounted) {
        final m = Map<String, dynamic>.from(jsonDecode(s));
        setState(() => plan = m.map((k, v) => MapEntry(k, List<String>.from(v))));
      }
    });
  }

  Future<void> save() async => (await SharedPreferences.getInstance()).setString('plan', jsonEncode(plan));

  void add() {
    final t = c.text.trim();
    if (t.isEmpty) return;
    setState(() => plan.putIfAbsent('$sel', () => []).add(t));
    c.clear();
    save();
  }

  @override
  Widget build(BuildContext context) {
    final list = plan['$sel'] ?? [];
    return _scaffold(
        'خطط لوقتك',
        ListView(padding: const EdgeInsets.all(16), children: [
          const Center(child: Illo(Ill.calendar, size: 110)),
          SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: [
                for (var i = 0; i < 7; i++)
                  Padding(
                      padding: const EdgeInsetsDirectional.only(end: 8),
                      child: ChoiceChip(label: Text(days[i]), selected: sel == i, selectedColor: _peri, onSelected: (_) => setState(() => sel = i))),
              ])),
          const SizedBox(height: 12),
          TextField(
              controller: c,
              onSubmitted: (_) => add(),
              decoration: _deco('مثال: 8:00 م - مراجعة 20 بطاقة').copyWith(suffixIcon: IconButton(icon: const Icon(Icons.add_circle, color: _ink), onPressed: add))),
          const SizedBox(height: 10),
          if (list.isEmpty) const Padding(padding: EdgeInsets.all(20), child: Center(child: Text('لا توجد خطة لهذا اليوم', style: TextStyle(color: _sub)))),
          for (var i = 0; i < list.length; i++)
            Container(
              margin: const EdgeInsets.only(bottom: 8),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
              child: ListTile(
                leading: const Icon(Icons.schedule, color: _ink),
                title: Text(list[i], style: const TextStyle(fontWeight: FontWeight.w700)),
                trailing: IconButton(
                    icon: const Icon(Icons.close, color: _sub),
                    onPressed: () {
                      setState(() => list.removeAt(i));
                      save();
                    }),
              ),
            ),
        ]));
  }
}

// ---------------- ركّز في دراستك ----------------
class FocusPage extends StatefulWidget {
  const FocusPage({super.key});
  @override
  State<FocusPage> createState() => _FocusState();
}

class _FocusState extends State<FocusPage> {
  int mins = 25;
  late int left = mins * 60;
  Timer? t;
  int sessions = 0;

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      if (mounted) setState(() => sessions = p.getInt('focusN') ?? 0);
    });
  }

  @override
  void dispose() {
    t?.cancel();
    super.dispose();
  }

  bool get running => t != null && t!.isActive;

  void toggle() {
    if (running) {
      t!.cancel();
      setState(() {});
      return;
    }
    t = Timer.periodic(const Duration(seconds: 1), (_) async {
      if (left <= 1) {
        t?.cancel();
        final p = await SharedPreferences.getInstance();
        sessions++;
        await p.setInt('focusN', sessions);
        if (!mounted) return;
        setState(() => left = mins * 60);
        showDialog(
            context: context,
            builder: (_) => AlertDialog(
                  content: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Illo(Ill.trophy, size: 110),
                    const Text('أحسنت! انتهت جلسة التركيز', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                  ]),
                  actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('حسنًا'))],
                ));
      } else {
        setState(() => left--);
      }
    });
    setState(() {});
  }

  void setMins(int m) {
    t?.cancel();
    setState(() {
      mins = m;
      left = m * 60;
    });
  }

  @override
  Widget build(BuildContext context) {
    final mm = (left ~/ 60).toString().padLeft(2, '0'), ss = (left % 60).toString().padLeft(2, '0');
    return _scaffold(
        'ركّز في دراستك',
        ListView(padding: const EdgeInsets.all(20), children: [
          const Center(child: Illo(Ill.focus, size: 140)),
          const SizedBox(height: 10),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            for (final m in [15, 25, 45])
              Padding(
                  padding: const EdgeInsets.all(4),
                  child: ChoiceChip(label: Text('$m د'), selected: mins == m, selectedColor: _peri, onSelected: (_) => setMins(m))),
          ]),
          const SizedBox(height: 16),
          Center(
              child: SizedBox(
            width: 220,
            height: 220,
            child: Stack(alignment: Alignment.center, children: [
              SizedBox.expand(child: CircularProgressIndicator(value: 1 - left / (mins * 60), strokeWidth: 12, color: _mint, backgroundColor: Colors.white)),
              Text('$mm:$ss', style: const TextStyle(fontSize: 46, fontWeight: FontWeight.w900)),
            ]),
          )),
          const SizedBox(height: 24),
          Row(children: [
            Expanded(
                child: FilledButton(
                    onPressed: toggle,
                    style: FilledButton.styleFrom(backgroundColor: _ink, padding: const EdgeInsets.all(16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                    child: Text(running ? 'إيقاف مؤقت' : 'ابدأ', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)))),
            const SizedBox(width: 10),
            OutlinedButton(
                onPressed: () => setMins(mins),
                style: OutlinedButton.styleFrom(padding: const EdgeInsets.all(16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                child: const Text('إعادة')),
          ]),
          const SizedBox(height: 16),
          Center(child: Text('جلسات مكتملة: $sessions', style: const TextStyle(color: _sub, fontWeight: FontWeight.w700))),
        ]));
  }
}

// ---------------- تنبيهات ومواعيد ----------------
class RemindersPage extends StatefulWidget {
  const RemindersPage({super.key});
  @override
  State<RemindersPage> createState() => _RemState();
}

class _RemState extends State<RemindersPage> {
  bool on = false;
  int h = 20, m = 0;
  String msg = '';

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      if (!mounted) return;
      setState(() {
        on = p.getBool('rem_on') ?? false;
        h = p.getInt('rem_h') ?? 20;
        m = p.getInt('rem_m') ?? 0;
      });
    });
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setBool('rem_on', on);
    await p.setInt('rem_h', h);
    await p.setInt('rem_m', m);
    try {
      if (on) {
        final ok = await Notif.requestPermission();
        if (!ok && mounted) setState(() => msg = 'لم يُمنح إذن الإشعارات. فعّله من إعدادات الهاتف ثم أعد المحاولة.');
      }
      await Notif.syncFromPrefs();
    } catch (_) {
      if (mounted) setState(() => msg = 'تعذر ضبط الإشعارات على هذا الجهاز');
    }
  }

  @override
  Widget build(BuildContext context) => _scaffold(
      'تنبيهات ومواعيد',
      ListView(padding: const EdgeInsets.all(20), children: [
        const Center(child: Illo(Ill.bell, size: 140)),
        SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('تذكير المراجعة اليومي', style: TextStyle(fontWeight: FontWeight.w800)),
            value: on,
            onChanged: (v) {
              setState(() {
                on = v;
                msg = '';
              });
              save();
            }),
        ListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('وقت التذكير', style: TextStyle(fontWeight: FontWeight.w700)),
          trailing: Text('${h.toString().padLeft(2, '0')}:${m.toString().padLeft(2, '0')}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          onTap: () async {
            final r = await showTimePicker(context: context, initialTime: TimeOfDay(hour: h, minute: m));
            if (r != null) {
              setState(() {
                h = r.hour;
                m = r.minute;
              });
              save();
            }
          },
        ),
        const SizedBox(height: 6),
        OutlinedButton(
            onPressed: () async {
              try {
                final ok = await Notif.requestPermission();
                if (!ok) {
                  setState(() => msg = 'لم يُمنح إذن الإشعارات.');
                  return;
                }
                await Notif.test();
              } catch (_) {
                setState(() => msg = 'تعذر إرسال الإشعار التجريبي');
              }
            },
            child: const Text('إرسال إشعار تجريبي')),
        if (msg.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: Text(msg, style: TextStyle(color: Colors.red.shade700, fontWeight: FontWeight.w700))),
        const SizedBox(height: 14),
        const Text('يصلك إشعار حقيقي كل يوم في الوقت المحدد حتى لو كان التطبيق مغلقًا. وإذا أنجزت هدفك اليومي قبل الوقت يُلغى إشعار اليوم تلقائيًا.\nقد يتأخر الإشعار دقائق قليلة لتوفير البطارية.',
            style: TextStyle(color: _sub, height: 1.7)),
      ]));
}
