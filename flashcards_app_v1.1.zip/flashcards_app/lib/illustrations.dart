import 'dart:math';
import 'package:flutter/material.dart';
import 'ai.dart';

enum Ill { student, calendar, books, tasks, bulb, target, focus, chart, quiz, cloud, moon, brain, notes, lessons, bell, trophy, phone }

/// رسم متجهي (بدون ملفات صور) يدعم الوضع الداكن.
class Illo extends StatelessWidget {
  final Ill kind;
  final double size;
  const Illo(this.kind, {super.key, this.size = 90});

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<bool>(
        valueListenable: darkN,
        builder: (_, d, __) => darkWrap(
            d, SizedBox(width: size, height: size, child: CustomPaint(painter: _IlloPainter(kind)))),
      );
}

class _IlloPainter extends CustomPainter {
  final Ill k;
  _IlloPainter(this.k);

  static const _ink = Color(0xFF1F2937);
  static const _skin = Color(0xFFF6CFA6);
  static const _green = Color(0xFF34C77B);
  static const _blue = Color(0xFF3B82F6);
  static const _gray = Color(0xFFC3C7D9);

  Paint _f(Color c) => Paint()..color = c;
  Paint _s(Color c, double w) => Paint()
    ..color = c
    ..style = PaintingStyle.stroke
    ..strokeWidth = w
    ..strokeCap = StrokeCap.round
    ..strokeJoin = StrokeJoin.round;

  void _rr(Canvas c, double l, double t, double w, double h, double r, Paint p) =>
      c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(l, t, w, h), Radius.circular(r)), p);

  void _blob(Canvas c, Color col) => c.drawOval(const Rect.fromLTWH(6, 16, 88, 76), _f(col.withOpacity(.35)));

  void _spark(Canvas c, Color col) {
    final p = _s(col, 2.5);
    c.drawLine(const Offset(80, 12), const Offset(86, 6), p);
    c.drawLine(const Offset(87, 20), const Offset(95, 18), p);
  }

  void _star(Canvas c, double x, double y, double r, Color col) {
    final p = Path()
      ..moveTo(x, y - r)
      ..lineTo(x + r * .3, y - r * .3)
      ..lineTo(x + r, y)
      ..lineTo(x + r * .3, y + r * .3)
      ..lineTo(x, y + r)
      ..lineTo(x - r * .3, y + r * .3)
      ..lineTo(x - r, y)
      ..lineTo(x - r * .3, y - r * .3)
      ..close();
    c.drawPath(p, _f(col));
  }

  @override
  void paint(Canvas c, Size size) {
    c.scale(size.width / 100, size.height / 100);
    switch (k) {
      case Ill.student:
        _person(c, false, true, const Color(0xFF72E3A5));
        break;
      case Ill.lessons:
        _person(c, false, true, const Color(0xFFB4E8C8));
        break;
      case Ill.focus:
        _person(c, true, false, const Color(0xFFB4BEFF));
        break;
      case Ill.calendar:
        _calendar(c);
        break;
      case Ill.books:
        _books(c);
        break;
      case Ill.tasks:
        _tasks(c);
        break;
      case Ill.bulb:
        _bulb(c);
        break;
      case Ill.target:
        _target(c);
        break;
      case Ill.chart:
        _chart(c);
        break;
      case Ill.quiz:
        _quiz(c);
        break;
      case Ill.cloud:
        _cloud(c);
        break;
      case Ill.moon:
        _moon(c);
        break;
      case Ill.brain:
        _brain(c);
        break;
      case Ill.notes:
        _notes(c);
        break;
      case Ill.bell:
        _bell(c);
        break;
      case Ill.trophy:
        _trophy(c);
        break;
      case Ill.phone:
        _phone(c);
        break;
    }
  }

  void _person(Canvas c, bool headphones, bool check, Color blob) {
    _blob(c, blob);
    _rr(c, 22, 52, 42, 40, 18, _f(_ink));
    c.drawCircle(const Offset(44, 38), 11, _f(_skin));
    c.drawArc(Rect.fromCircle(center: const Offset(44, 38), radius: 11.5), pi, pi, true, _f(_ink));
    if (headphones) {
      c.drawArc(Rect.fromCircle(center: const Offset(44, 38), radius: 14), pi, pi, false, _s(const Color(0xFF6B7FD7), 3));
      _rr(c, 28, 36, 5, 10, 2, _f(const Color(0xFF6B7FD7)));
      _rr(c, 55, 36, 5, 10, 2, _f(const Color(0xFF6B7FD7)));
      final book = Path()
        ..moveTo(40, 76)
        ..lineTo(58, 70)
        ..lineTo(78, 76)
        ..lineTo(78, 90)
        ..lineTo(58, 84)
        ..lineTo(40, 90)
        ..close();
      c.drawPath(book, _f(Colors.white));
      c.drawPath(book, _s(_ink, 1.6));
      c.drawLine(const Offset(58, 70), const Offset(58, 84), _s(_ink, 1.6));
    } else {
      _rr(c, 44, 66, 36, 20, 3, _f(const Color(0xFF8E93A8)));
      _rr(c, 40, 85, 44, 4, 2, _f(_gray));
    }
    if (check) {
      c.drawCircle(const Offset(78, 24), 9, _f(_green));
      c.drawPath(
          Path()
            ..moveTo(73, 24)
            ..lineTo(77, 28)
            ..lineTo(83, 20),
          _s(Colors.white, 2.6));
    } else {
      _spark(c, const Color(0xFF8B7BE8));
    }
  }

  void _calendar(Canvas c) {
    _blob(c, const Color(0xFFB4D0FF));
    _rr(c, 16, 28, 58, 54, 8, _f(Colors.white));
    _rr(c, 16, 28, 58, 15, 8, _f(_blue));
    c.drawRect(const Rect.fromLTWH(16, 36, 58, 7), _f(_blue));
    _rr(c, 16, 28, 58, 54, 8, _s(_ink, 2.4));
    c.drawLine(const Offset(32, 22), const Offset(32, 33), _s(_ink, 3));
    c.drawLine(const Offset(58, 22), const Offset(58, 33), _s(_ink, 3));
    for (var r = 0; r < 3; r++) {
      for (var q = 0; q < 4; q++) {
        _rr(c, 22.0 + q * 12, 50.0 + r * 10, 7, 6, 1.5, _f(r == 1 && q == 1 ? _green : _gray));
      }
    }
    c.drawCircle(const Offset(72, 72), 16, _f(Colors.white));
    c.drawCircle(const Offset(72, 72), 16, _s(_ink, 3));
    c.drawLine(const Offset(72, 72), const Offset(72, 62), _s(_ink, 3));
    c.drawLine(const Offset(72, 72), const Offset(79, 75), _s(_ink, 3));
    _spark(c, _blue);
  }

  void _books(Canvas c) {
    _blob(c, const Color(0xFFD1C2FF));
    _rr(c, 14, 66, 70, 15, 3, _f(const Color(0xFF3D5AA8)));
    _rr(c, 14, 66, 70, 15, 3, _s(_ink, 1.6));
    _rr(c, 20, 52, 62, 14, 3, _f(_green));
    _rr(c, 20, 52, 62, 14, 3, _s(_ink, 1.6));
    _rr(c, 24, 40, 54, 12, 3, _f(Colors.white));
    _rr(c, 24, 40, 54, 12, 3, _s(_ink, 1.6));
    final cap = Path()
      ..moveTo(50, 14)
      ..lineTo(80, 26)
      ..lineTo(50, 38)
      ..lineTo(20, 26)
      ..close();
    c.drawPath(cap, _f(_ink));
    _rr(c, 36, 32, 28, 10, 4, _f(_ink));
    c.drawLine(const Offset(78, 27), const Offset(78, 40), _s(const Color(0xFFFFC233), 2.4));
    _spark(c, const Color(0xFF8B7BE8));
  }

  void _tasks(Canvas c) {
    _blob(c, const Color(0xFFBFEBD2));
    _rr(c, 22, 20, 54, 68, 8, _f(Colors.white));
    _rr(c, 22, 20, 54, 68, 8, _s(_ink, 3));
    _rr(c, 38, 13, 22, 12, 4, _f(_ink));
    for (var i = 0; i < 3; i++) {
      final y = 36.0 + i * 16;
      _rr(c, 30, y, 10, 10, 2, _f(i == 0 ? _green : _gray));
      c.drawLine(Offset(46, y + 3), Offset(68, y + 3), _s(_gray, 2.4));
      c.drawLine(Offset(46, y + 9), Offset(62, y + 9), _s(_gray, 2.4));
    }
    c.drawPath(
        Path()
          ..moveTo(32, 41)
          ..lineTo(35, 44)
          ..lineTo(39, 38),
        _s(Colors.white, 2));
  }

  void _bulb(Canvas c) {
    _blob(c, const Color(0xFFFFE3A3));
    c.drawCircle(const Offset(50, 42), 24, _f(const Color(0xFFFFC857)));
    _rr(c, 40, 62, 20, 8, 3, _f(const Color(0xFFB8BCCB)));
    _rr(c, 42, 70, 16, 8, 3, _f(_ink));
    c.drawPath(
        Path()
          ..moveTo(42, 56)
          ..lineTo(42, 44)
          ..lineTo(50, 52)
          ..lineTo(58, 44)
          ..lineTo(58, 56),
        _s(const Color(0xFFE08A1E), 2.6));
    c.drawArc(Rect.fromCircle(center: const Offset(50, 42), radius: 16), pi * 1.05, pi * .35, false, _s(Colors.white.withOpacity(.7), 3));
    _spark(c, const Color(0xFFFFB020));
  }

  void _target(Canvas c) {
    _blob(c, const Color(0xFFFFC2CC));
    const o = Offset(46, 56);
    c.drawCircle(o, 34, _f(const Color(0xFFFF6B7A)));
    c.drawCircle(o, 25, _f(Colors.white));
    c.drawCircle(o, 16, _f(const Color(0xFFFF6B7A)));
    c.drawCircle(o, 7, _f(Colors.white));
    c.drawLine(o, const Offset(80, 22), _s(_ink, 4));
    c.drawLine(const Offset(80, 22), const Offset(80, 12), _s(_ink, 4));
    c.drawLine(const Offset(80, 22), const Offset(90, 22), _s(_ink, 4));
    _spark(c, const Color(0xFFFF6B7A));
  }

  void _chart(Canvas c) {
    _blob(c, const Color(0xFFBFEBD2));
    _rr(c, 16, 64, 13, 18, 3, _f(const Color(0xFFB8BCCB)));
    _rr(c, 34, 54, 13, 28, 3, _f(const Color(0xFF9FA6BC)));
    _rr(c, 52, 44, 13, 38, 3, _f(const Color(0xFF7BCB9C)));
    _rr(c, 70, 32, 13, 50, 3, _f(_green));
    c.drawPath(
        Path()
          ..moveTo(16, 50)
          ..quadraticBezierTo(46, 44, 74, 20),
        _s(_ink, 3.4));
    c.drawPath(
        Path()
          ..moveTo(64, 20)
          ..lineTo(76, 18)
          ..lineTo(74, 30),
        _s(_ink, 3.4));
  }

  void _quiz(Canvas c) {
    _blob(c, const Color(0xFFB4D0FF));
    _rr(c, 16, 22, 48, 62, 6, _f(Colors.white));
    _rr(c, 16, 22, 48, 62, 6, _s(_ink, 2.4));
    for (var i = 0; i < 4; i++) {
      final y = 32.0 + i * 13;
      _rr(c, 22, y, 7, 7, 1.5, _s(_ink, 1.8));
      c.drawLine(Offset(34, y + 3.5), Offset(56, y + 3.5), _s(_gray, 2.6));
    }
    c.save();
    c.translate(70, 54);
    c.rotate(0.6);
    _rr(c, -5, -26, 10, 44, 3, _f(_ink));
    c.drawPath(
        Path()
          ..moveTo(-5, 18)
          ..lineTo(0, 28)
          ..lineTo(5, 18)
          ..close(),
        _f(const Color(0xFFF6CFA6)));
    _rr(c, -5, -26, 10, 8, 3, _f(_blue));
    c.restore();
  }

  void _cloud(Canvas c) {
    _blob(c, const Color(0xFFB4D0FF));
    final p = _f(_blue);
    c.drawCircle(const Offset(34, 58), 15, p);
    c.drawCircle(const Offset(52, 46), 20, p);
    c.drawCircle(const Offset(72, 58), 14, p);
    _rr(c, 30, 56, 50, 17, 8, p);
    c.drawLine(const Offset(54, 70), const Offset(54, 50), _s(Colors.white, 4));
    c.drawPath(
        Path()
          ..moveTo(45, 58)
          ..lineTo(54, 49)
          ..lineTo(63, 58),
        _s(Colors.white, 4));
    _spark(c, _blue);
  }

  void _moon(Canvas c) {
    _blob(c, const Color(0xFFC9C2FF));
    c.drawCircle(const Offset(50, 54), 32, _f(const Color(0xFF3B3F7A)));
    c.drawCircle(const Offset(42, 54), 22, _f(const Color(0xFFE8E4FF)));
    c.drawCircle(const Offset(54, 48), 21, _f(const Color(0xFF3B3F7A)));
    _star(c, 66, 58, 5, Colors.white);
    _star(c, 58, 74, 3.5, Colors.white);
    _star(c, 78, 22, 4, const Color(0xFF8B7BE8));
  }

  void _brain(Canvas c) {
    _blob(c, const Color(0xFFD9CCFF));
    final p = _f(const Color(0xFF9B7FD6));
    c.drawCircle(const Offset(38, 44), 16, p);
    c.drawCircle(const Offset(62, 42), 18, p);
    c.drawCircle(const Offset(38, 62), 15, p);
    c.drawCircle(const Offset(63, 62), 15, p);
    _rr(c, 30, 40, 40, 30, 10, p);
    final l = _s(const Color(0xFF6D4FB5), 2.4);
    c.drawLine(const Offset(50, 28), const Offset(50, 76), l);
    c.drawArc(const Rect.fromLTWH(30, 40, 16, 12), pi, pi * 1.2, false, l);
    c.drawArc(const Rect.fromLTWH(54, 38, 16, 12), pi * 1.3, pi * 1.2, false, l);
    c.drawArc(const Rect.fromLTWH(30, 58, 16, 12), 0, pi * 1.2, false, l);
    c.drawArc(const Rect.fromLTWH(54, 58, 16, 12), pi * .8, pi * 1.2, false, l);
    _spark(c, const Color(0xFF8B7BE8));
  }

  void _notes(Canvas c) {
    _blob(c, const Color(0xFFBFEBD2));
    _rr(c, 16, 26, 58, 58, 6, _f(Colors.white));
    _rr(c, 16, 26, 58, 58, 6, _s(_ink, 2.4));
    for (var i = 0; i < 4; i++) {
      c.drawLine(Offset(24, 40.0 + i * 11), Offset(i == 3 ? 46 : 64, 40.0 + i * 11), _s(_blue.withOpacity(.55), 3));
    }
    final b = Path()
      ..moveTo(58, 16)
      ..lineTo(72, 16)
      ..lineTo(72, 44)
      ..lineTo(65, 37)
      ..lineTo(58, 44)
      ..close();
    c.drawPath(b, _f(const Color(0xFF2FA37A)));
  }

  void _bell(Canvas c) {
    _blob(c, const Color(0xFFFFC2CC));
    final p = _f(const Color(0xFF2D3748));
    c.drawCircle(const Offset(48, 46), 22, p);
    _rr(c, 26, 46, 44, 22, 4, p);
    _rr(c, 20, 64, 56, 8, 4, p);
    c.drawCircle(const Offset(48, 24), 4, p);
    c.drawCircle(const Offset(48, 80), 6, p);
    c.drawCircle(const Offset(72, 26), 9, _f(const Color(0xFFFF4D5E)));
    c.drawCircle(const Offset(72, 26), 4, _f(Colors.white));
  }

  void _trophy(Canvas c) {
    _blob(c, const Color(0xFFFFE3A3));
    const gold = Color(0xFFFFC233);
    c.drawArc(const Rect.fromLTWH(18, 24, 24, 24), pi * .5, pi, false, _s(gold, 4));
    c.drawArc(const Rect.fromLTWH(58, 24, 24, 24), pi * 1.5, pi, false, _s(gold, 4));
    c.drawRRect(RRect.fromLTRBAndCorners(30, 18, 70, 54, bottomLeft: const Radius.circular(20), bottomRight: const Radius.circular(20)), _f(gold));
    _rr(c, 45, 54, 10, 12, 2, _f(gold));
    _rr(c, 32, 66, 36, 10, 3, _f(_ink));
    _star(c, 50, 36, 8, Colors.white);
    _spark(c, const Color(0xFFFFB020));
  }

  void _phone(Canvas c) {
    _blob(c, const Color(0xFFB4D0FF));
    _rr(c, 28, 12, 44, 76, 9, _f(Colors.white));
    _rr(c, 28, 12, 44, 76, 9, _s(_ink, 4));
    final cap = Path()
      ..moveTo(50, 36)
      ..lineTo(62, 42)
      ..lineTo(50, 48)
      ..lineTo(38, 42)
      ..close();
    c.drawPath(cap, _f(_ink));
    _rr(c, 44, 44, 12, 6, 2, _f(_ink));
    c.drawLine(const Offset(36, 62), const Offset(64, 62), _s(_gray, 3));
    c.drawLine(const Offset(36, 70), const Offset(56, 70), _s(_gray, 3));
    c.drawLine(const Offset(44, 82), const Offset(56, 82), _s(_ink, 2.4));
    _spark(c, _blue);
  }

  @override
  bool shouldRepaint(_IlloPainter old) => old.k != k;
}
