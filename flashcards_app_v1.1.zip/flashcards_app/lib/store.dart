import 'dart:async';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'models.dart';

class _Snap {
  final String j;
  final int mt;
  _Snap(this.j, this.mt);
}

class _W {
  final String id, deck, j;
  _W(this.id, this.deck, this.j);
}

/// تخزين البطاقات في SQLite مع ترحيل تلقائي من SharedPreferences.
/// الحفظ تفاضلي: تُكتب البطاقات المتغيّرة فقط، وتُسجَّل المحذوفات للمزامنة.
class Store {
  static Database? _db;
  static final Map<String, _Snap> _snap = {};
  static Future<void> _q = Future.value();

  // كل العمليات تمرّ في طابور واحد حتى لا تتداخل
  static Future<T> _run<T>(Future<T> Function() f) {
    final c = Completer<T>();
    _q = _q.then((_) async {
      try {
        c.complete(await f());
      } catch (e, s) {
        c.completeError(e, s);
      }
    });
    return c.future;
  }

  static Future<Database> _open() async {
    if (_db != null) return _db!;
    final path = '${await getDatabasesPath()}/flashcards.db';
    _db = await openDatabase(path, version: 1, onCreate: (db, v) async {
      await db.execute('CREATE TABLE cards (id TEXT PRIMARY KEY, deck TEXT, data TEXT NOT NULL)');
    });
    return _db!;
  }

  static Future<List<Flash>> load() => _run(_load);
  static Future<void> save(List<Flash> cards) => _run(() => _save(cards));

  static Future<List<Flash>> _load() async {
    final db = await _open();
    final p = await SharedPreferences.getInstance();
    var rows = await db.query('cards', orderBy: 'rowid');
    final legacy = p.getString('cards');
    if (rows.isEmpty && legacy != null && legacy.isNotEmpty) {
      try {
        final list = jsonDecode(legacy) as List;
        await db.transaction((txn) async {
          for (final e in list) {
            final m = Map<String, dynamic>.from(e as Map);
            await txn.insert(
                'cards', {'id': m['id'].toString(), 'deck': (m['d'] ?? 'عام').toString(), 'data': jsonEncode(m)},
                conflictAlgorithm: ConflictAlgorithm.replace);
          }
        });
        await p.setString('cards_legacy', legacy); // نسخة احتياطية من البيانات القديمة
        await p.remove('cards');
        rows = await db.query('cards', orderBy: 'rowid');
      } catch (_) {}
    }
    _snap.clear();
    final out = <Flash>[];
    for (final r in rows) {
      try {
        final f = Flash.fromJson(Map<String, dynamic>.from(jsonDecode(r['data'] as String) as Map));
        out.add(f);
        _snap[f.id] = _Snap(jsonEncode(f.toJson()), f.mt);
      } catch (_) {}
    }
    return out;
  }

  static Future<void> _save(List<Flash> cards) async {
    final db = await _open();
    final now = DateTime.now().millisecondsSinceEpoch;
    final ids = <String>{};
    final writes = <_W>[];
    for (final c in cards) {
      ids.add(c.id);
      var j = jsonEncode(c.toJson());
      final prev = _snap[c.id];
      if (prev == null) {
        if (c.mt == 0) {
          c.mt = now;
          j = jsonEncode(c.toJson());
        }
        writes.add(_W(c.id, c.d, j));
      } else if (j != prev.j) {
        // نحدّث وقت التعديل فقط إذا لم تحدّده المزامنة صراحةً
        if (c.mt == prev.mt) {
          c.mt = now;
          j = jsonEncode(c.toJson());
        }
        writes.add(_W(c.id, c.d, j));
      }
      _snap[c.id] = _Snap(j, c.mt);
    }
    final gone = _snap.keys.where((k) => !ids.contains(k)).toList();
    for (final g in gone) {
      _snap.remove(g);
    }
    if (writes.isEmpty && gone.isEmpty) return;
    try {
      await db.transaction((txn) async {
        for (final w in writes) {
          final n = await txn.update('cards', {'deck': w.deck, 'data': w.j}, where: 'id = ?', whereArgs: [w.id]);
          if (n == 0) await txn.insert('cards', {'id': w.id, 'deck': w.deck, 'data': w.j});
        }
        for (final id in gone) {
          await txn.delete('cards', where: 'id = ?', whereArgs: [id]);
        }
      });
    } catch (e) {
      _snap.clear(); // سيُعاد كتابة كل شيء في الحفظ التالي
      rethrow;
    }
    if (gone.isNotEmpty) {
      final d = await dead();
      for (final g in gone) {
        d[g] = now;
      }
      await setDead(d);
    }
  }

  /// سجل المحذوفات (id -> وقت الحذف) لمنع عودة البطاقات المحذوفة عند المزامنة
  static Future<Map<String, int>> dead() async {
    final p = await SharedPreferences.getInstance();
    try {
      final m = Map<String, dynamic>.from(jsonDecode(p.getString('dead') ?? '{}'));
      return {for (final e in m.entries) e.key: (e.value as num).toInt()};
    } catch (_) {
      return {};
    }
  }

  static Future<void> setDead(Map<String, int> m) async {
    final p = await SharedPreferences.getInstance();
    final cut = DateTime.now().millisecondsSinceEpoch - 120 * 86400000;
    final keep = {for (final e in m.entries) if (e.value > cut) e.key: e.value};
    await p.setString('dead', jsonEncode(keep));
  }
}
