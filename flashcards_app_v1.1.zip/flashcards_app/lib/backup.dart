import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'illustrations.dart';
import 'io_tools.dart';
import 'models.dart';
import 'ui.dart';

class BackupPage extends StatefulWidget {
  final List<Flash> cards;
  final void Function(List<Flash>) onImport;
  const BackupPage({super.key, required this.cards, required this.onImport});
  @override
  State<BackupPage> createState() => _BackupState();
}

class _BackupState extends State<BackupPage> {
  final c = TextEditingController();
  String msg = '';
  bool err = false;

  void say(String m, {bool bad = false}) => setState(() {
        msg = m;
        err = bad;
      });

  Future<void> shareFile(String name, String content, String mime) async {
    if (widget.cards.isEmpty) {
      say('لا توجد بطاقات للتصدير', bad: true);
      return;
    }
    try {
      final dir = await getTemporaryDirectory();
      final f = File('${dir.path}/$name');
      await f.writeAsString(content, encoding: utf8);
      await Share.shareXFiles([XFile(f.path, mimeType: mime)], subject: name);
      say('تم تجهيز الملف $name');
    } catch (e) {
      say('تعذر إنشاء الملف', bad: true);
    }
  }

  /// يتخطى المكررات (نفس الكلمة في نفس المجموعة) ثم يضيف الباقي
  void apply(List<Flash> list) {
    final have = widget.cards.map((x) => '${x.d}|${x.w.toLowerCase()}').toSet();
    final fresh = <Flash>[];
    var dup = 0;
    for (final f in list) {
      if (have.add('${f.d}|${f.w.toLowerCase()}')) {
        fresh.add(f);
      } else {
        dup++;
      }
    }
    if (fresh.isEmpty) {
      say(list.isEmpty ? 'لا توجد بطاقات صالحة في الملف' : 'كل البطاقات مكررة ($dup)، لم يُضف شيء', bad: true);
      return;
    }
    widget.onImport(fresh);
    say('تم استيراد ${fresh.length} بطاقة${dup > 0 ? ' · تخطي $dup مكررة' : ''}');
  }

  Future<void> importFile() async {
    try {
      final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['csv', 'txt', 'tsv', 'json'], withData: true);
      if (r == null || r.files.isEmpty) return;
      final f = r.files.first;
      final bytes = f.bytes ?? await File(f.path!).readAsBytes();
      apply(parseAnyCards(utf8.decode(bytes, allowMalformed: true)));
    } catch (_) {
      say('تعذر قراءة الملف. تأكد أنه CSV أو JSON أو نص Anki.', bad: true);
    }
  }

  void importPaste() {
    try {
      apply(parseAnyCards(c.text));
      if (!err) c.clear();
    } catch (_) {
      say('تعذر قراءة النص. تأكد من الصيغة.', bad: true);
    }
  }

  Widget sec(String s) => Padding(padding: const EdgeInsets.only(top: 22, bottom: 8), child: Text(s, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)));

  @override
  Widget build(BuildContext context) => uiPage(
      'نسخ واستيراد وتصدير',
      Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Center(child: Illo(Ill.cloud, size: 100)),
        sec('تصدير (ملف يمكن مشاركته)'),
        uiBtn('نسخة كاملة JSON (بكل بيانات الحفظ)', () => shareFile('flashcards_backup.json', jsonEncode({'v': 2, 'cards': widget.cards.map((e) => e.toJson()).toList()}), 'application/json')),
        const SizedBox(height: 8),
        uiBtn('CSV (Excel / Google Sheets)', () => shareFile('flashcards.csv', cardsToCsv(widget.cards), 'text/csv'), c: Colors.white, fg: kInk),
        const SizedBox(height: 8),
        uiBtn('ملف Anki (استيراد نصي)', () => shareFile('flashcards_anki.txt', cardsToAnki(widget.cards), 'text/plain'), c: Colors.white, fg: kInk),
        const SizedBox(height: 8),
        uiBtn('نسخ JSON إلى الحافظة', () {
          Clipboard.setData(ClipboardData(text: jsonEncode(widget.cards.map((e) => e.toJson()).toList())));
          say('تم النسخ، الصقه في أي مكان للاحتفاظ به');
        }, c: Colors.white, fg: kInk),
        sec('استيراد'),
        uiBtn('اختر ملفًا (CSV / JSON / Anki)', importFile),
        const SizedBox(height: 14),
        const Text('أو الصق JSON أو قائمة (كلمة، ترجمة) في كل سطر:', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        TextField(controller: c, minLines: 5, maxLines: 10, textDirection: TextDirection.ltr, decoration: uiDeco('apple, تفاحة')),
        const SizedBox(height: 10),
        uiBtn('استيراد من النص', importPaste),
        if (msg.isNotEmpty)
          Padding(
              padding: const EdgeInsets.only(top: 14),
              child: Text(msg, style: TextStyle(color: err ? Colors.red.shade700 : const Color(0xFF0A7A45), fontWeight: FontWeight.w700))),
      ]));
}
